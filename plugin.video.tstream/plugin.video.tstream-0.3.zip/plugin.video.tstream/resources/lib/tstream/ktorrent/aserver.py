from json import dumps
from mimetypes import guess_type
from os import fstat
from shutil import copyfileobj
from time import sleep, time
from urllib import unquote

import socket
import asyncore, scheduler
import re
import rfc822
	
from threading import Thread
    
HTTP_VERSION = '1.1'
SERVER_NAME = 'ikeHTTP/0.1'
	
from constants import RECV_BUFFER_SIZE, SEND_BUFFER_SIZE, STREAM_BUFFER_PIECES
from logger import log
from torrent import Torrent

class TorrentStream(object):
	def __init__(self, rfile, wfile, torrent, first, last):
		self.rfile = rfile
		self.wfile = wfile
		self.torrent = torrent
		self.file = torrent.downloader.file
		self.start_piece = torrent.get_piece_from_offset(self.file, first)
		self.end_piece = torrent.get_piece_from_offset(self.file, last)
		self.first = first
		self.last = last
		self._piece = self.start_piece
		self._left = last - first + 1
		self._buffering = False
		self.init()
		
	def init(self):
		new_pieces = []
		for piece_index in range(self.start_piece, self.end_piece + 1, 1):
			if not self.torrent.has_piece(piece_index):
				new_pieces.append(piece_index)
				
		self.torrent.downloader.pieces_first = new_pieces + self.torrent.downloader.pieces_first
		#log(self.torrent.downloader.pieces_first)
		
	def buffer(self):
		buffer_pieces = max(1024*1024/self.torrent.piece_length, STREAM_BUFFER_PIECES) # TODO: check convenience when pieces are too small
		for piece_index in range(self._piece, min(self._piece + buffer_pieces, self.end_piece + 1) , 1):
			while not self.torrent.has_piece(piece_index):
				sleep(0.1)
				
		self._buffering = False
				
	def push(self):
		while self._left > 0:
			if self.torrent.has_piece(self._piece):
				if self._piece == self.start_piece:
					self.rfile.seek(self.first)
					read_length = self.torrent.piece_length - (self.file['begin_offset'] + self.first - self.start_piece * self.torrent.piece_length)
				else:
					read_length = min(self.torrent.piece_length, self._left)
				log('reading piece %d bytes %d' % (self._piece, read_length))
				buffer = self.rfile.read(read_length)
				if buffer:
					self.wfile.write(buffer)
					self._left -= len(buffer)
					self._piece += 1
				else:
					log('no buffer available')
					break
			elif not self._buffering:
				self._buffering = True
				self.buffer()

class HTTPHandler(asyncore.dispatcher):
	def __init__(self, client, path, server):
		asyncore.dispatcher.__init__(self, client)
		self.path = path
		self.server = server
		self.rfile = self.makefile('rb')
		self.wfile = self.makefile('wb')
		
	def handle_read(self):
		request_header = self.recv(RECV_BUFFER_SIZE)
		request_header = unquote(request_header)
		print request_header

		if request_header == '':
			self.send_error(405, 'Method Not Allowed')
			self.close()
			return

		request_type = request_header.splitlines()[0]
		' '.join(request_type.split())

		chunks = request_type.split(' ')
		method = chunks[0].lower()
		http_version = chunks[-1].lower()
		self.path = request_type[len(method)+1:-len(http_version)-1]
		
		if 'head' in method: 
			self.do_HEAD()
			self.close()
		elif 'get' in method:
			self.do_GET()
		else:
			self.send_error(405, 'Method Not Allowed')
			self.close()

	def handle_write(self):
		pass
		
			
	def handle_close(self):
		log('handle_close')
		self.close()
	
	def send_response(self, code, text='OK'):
		response = ''
		response += 'HTTP/%s %d %s\r\n' % (HTTP_VERSION, code, text)
		response += 'Server: %s\r\n' % SERVER_NAME
		response += 'Date: %s\r\n' % str(rfc822.formatdate(time()))
		self.wfile.write(response)
	
	def send_error(self, code, text):
		error = ''
		error += 'HTTP/%s %d %s\r\n' % (HTTP_VERSION, code, text)
		error += 'Server: %s\r\n' % SERVER_NAME
		error += 'Date: %s\r\n' % str(rfc822.formatdate(time()))
		error += 'Content-Type: text/html; charset=UTF-8\r\n'
		error += 'Connection: close\r\n\r\n'
		error += '<html><head><title>%d</title></head><body><h2>%d %s</h2></body></html>' % (code, code, text)
		self.wfile.write(error)
	
	def send_header(self, key, value):
		header = '%s: %s\r\n' % (key, value)
		self.wfile.write(header)
	
	def end_headers(self):
		self.wfile.write('\r\n')
	
	def send_stream(self, file, first, last):
		torrent = self.server.torrent_server.torrent
		stream = TorrentStream(file, self.wfile, torrent, first, last)
		stream.push()
	
	def do_GET(self):
		log('do_GET')
		file, range = self.send_head()
		if file:
			try:
				if range: # need to make range global
					first, last = range 
					self.send_stream(file, first, last)
				else:
					copyfileobj(file, self.wfile)
			finally:
				file.close()
	
	def do_HEAD(self):
		log('do_HEAD')
		file, range = self.send_head()
		if file:
			file.close()
		self.close() # TO BE REVIEWED
			
	def send_head(self):
		range = None
		file = None
		file_path = None
		file_len = 0
		file_time = 0
		json_response = ''
		
		request_path, request_params = self.parse_request_path(self.path)
		
		if request_path == '/retr': # RETR TORRENT
			torrent_dir = unquote(request_params['path']) if 'path' in request_params else None
			torrent_file = unquote(request_params['file']) if 'file' in request_params else None
			if torrent_file:
				if self.server.torrent_server.torrent:
					log('stopping thread')
					self.server.torrent_server.torrent.stop()
					self.server.torrent_server.torrent = None
				self.server.torrent_server.torrent = Torrent()
				self.server.torrent_server.torrent.start(torrent_file, torrent_dir)	
				json_response = dumps(self.server.torrent_server.torrent.files)
			self.send_json_response(json_response)
		elif request_path == '/down': # DOWN FILE
			torrent_dir = unquote(request_params['path']) if 'path' in request_params else None
			file_index = int(request_params['index']) if 'index' in request_params and request_params['index'].isdigit() else 0
			if self.server.torrent_server.torrent and file_index < len(self.server.torrent_server.torrent.files):
				self.server.torrent_server.torrent.download(file_index, torrent_dir, True)				
				json_response = dumps(self.server.torrent_server.torrent.files[file_index])
			self.send_json_response(json_response)
		elif request_path == '/info': # INFO FILE
			log('/info')
			if self.server.torrent_server.torrent and self.server.torrent_server.torrent.downloader:
				json_response = dumps({'ready':True, 'files':self.server.torrent_server.torrent.files, 'name': self.server.torrent_server.torrent.downloader.file['name'], 'path':self.server.torrent_server.torrent.downloader.get_file_path(), 'length':self.server.torrent_server.torrent.downloader.file['length'], 'downloaded': self.server.torrent_server.torrent.downloader.downloaded_bytes, 'progress':self.server.torrent_server.torrent.downloader.downloaded_percent, 'speed':self.server.torrent_server.torrent.downloader.download_speed, 'active_peers': len(self.server.torrent_server.torrent.downloader.active_peers), 'total_peers': len(self.server.torrent_server.torrent.downloader.started_peers)})
			elif self.server.torrent_server.torrent:
				json_response = dumps({'ready':False, 'files':self.server.torrent_server.torrent.files})
			else:
				json_response = dumps({'ready':False})
			self.send_json_response(json_response)
		elif request_path == '/play': # PLAY FILE
			file_path = unquote(request_params['file']) if 'file' in request_params else None
			file_path = self.server.torrent_server.torrent.downloader.get_file_path() if not file_path and self.server.torrent_server and self.server.torrent_server.torrent and self.server.torrent_server.torrent.downloader and self.server.torrent_server.torrent.downloader.get_file_path() else file_path
			file_len = self.server.torrent_server.torrent.downloader.file['length'] if self.server.torrent_server and self.server.torrent_server.torrent and self.server.torrent_server.torrent.downloader and self.server.torrent_server.torrent.downloader.file and 'length' in self.server.torrent_server.torrent.downloader.file else 0
			log('file is %s' % file_path)
			try:
				file = open(file_path, 'rb')
				fs = fstat(file.fileno())
				file_len = fs[6] if not file_len else file_len
				file_time = fs.st_mtime
				file_type = guess_type(file_path)[0]
			except IOError:
				self.send_error(404, 'File not found')
				return file, range
			
			if 'Range' in self.headers:
				log('Range requested %s' % self.headers['Range'])
				try:
					range = self.parse_range(self.headers['Range'])
				except ValueError as e:
					self.send_error(400, 'Invalid byte range')
					return file, range
				
				first, last = range				
				if first >= file_len:
					self.send_error(416, 'Requested range not satisfiable')
					return file, None

				if last is None or last >= file_len:
					last = file_len - 1
				response_length = last - first + 1

				range = first, last
				
				log('type: %s  bytes: %d-%d/%d' % (file_type, first, last, file_len))
				
				self.send_response(206)
				self.send_header('Content-Type', file_type)
				self.send_header('Accept-Ranges', 'bytes')
				self.send_header('Content-Range', 'bytes %d-%d/%d' % (first, last, file_len))
				self.send_header('Content-Length', str(response_length))
				self.send_header('Last-Modified', str(rfc822.formatdate(file_time)))
				self.end_headers()
			else:
				self.send_response(200)
				self.send_header('Content-Type', file_type)
				self.send_header('Accept-Ranges', 'bytes')
				self.send_header('Content-Length', str(file_len))
				self.send_header('Last-Modified', str(rfc822.formatdate(file_time)))
				self.end_headers()
		elif request_path == '/stop': # STOP TORRENT
			if self.server.torrent_server.torrent:
				log('stopping thread')
				self.server.torrent_server.torrent.stop()
				self.server.torrent_server.torrent = None
		else:
			self.send_json_response(json_response)
		
		return file, range
	
	def send_json_response(self, data=None):
		self.send_response(200)
		if data and len(data) > 0:
			self.send_header('Content-type', 'application/json')
			self.send_header('Content-length', '%d' % len(data))
			self.end_headers()
			self.wfile.write(data)
		else:
			self.end_headers()
		
	def parse_request_path(self, full_path):
		request_path = None
		request_params = {}
		if '?' in full_path:
			split_path = full_path.split('?')
			request_path = split_path[0]
			if len(split_path) > 1:
				split_params = split_path[1].split('&')
				for param in split_params:
					if '=' in param:
						split_param = param.split('=')
						if len(split_param) > 1:
							request_params[split_param[0]] = split_param[1]
		else:
			request_path = full_path
			
		return request_path, request_params
	
	def parse_range(self, byte_range):
		BYTE_RANGE_RE = re.compile(r'bytes=(\d+)-(\d+)?$')
		if byte_range.strip() == '':
			return None, None
		
		m = BYTE_RANGE_RE.match(byte_range)
		if not m:
			raise ValueError('Invalid byte range %s' % byte_range)
		
		first, last = [x and int(x) for x in m.groups()]
		if last and last < first:
			raise ValueError('Invalid byte range %s' % byte_range)
		
		return first, last

class TorrentStreamServer(asyncore.dispatcher):
	def __init__(self, host='', port=8080):
		asyncore.dispatcher.__init__(self)
		self.addr = (host, port)
		self.torrent = None
		self.torrent_server = self
		
	def start(self, threaded=True):
		self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
		self.set_reuse_addr()
		self.bind(self.addr)
		self.listen(5)
		self.server_thread = Thread(target=scheduler.loop) if threaded else None
		if self.server_thread:
			self.server_thread.daemon = True
			self.server_thread.start()    

	def handle_accept(self):
		try:
			client, addr = self.accept()
			handler = HTTPHandler(client, addr, self)
		except:
			return

if __name__ == '__main__':
	server = TorrentStreamServer(port=8080)
	server.start()
	scheduler.loop()