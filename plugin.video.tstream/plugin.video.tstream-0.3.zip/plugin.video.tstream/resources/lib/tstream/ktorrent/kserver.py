"""Simple HTTP server based on the asyncore / asynchat framework

Under asyncore, every time a socket is created it enters a table which is
scanned through select calls by the asyncore.loop() function

All events (a client connecting to a server socket, a client sending data, 
a server receiving data) is handled by the instances of classes derived 
from asyncore.dispatcher

Here the server is represented by an instance of the Server class

When a client connects to it, its handle_accept() method creates an
instance of RequestHandler, one for each HTTP request. It is derived
from asynchat.async_chat, a class where incoming data on the connection
is processed when a "terminator" is received. The terminator can be :
- a string : here we'll use the string \r\n\r\n to handle the HTTP request
line and the HTTP headers
- an integer (n) : the data is processed when n bytes have been read. This
will be used for HTTP POST requests

The data is processed by a method called found_terminator. In RequestHandler,
found_terminator is first set to handle_request_line to handle the HTTP
request line (including the decoding of the query string) and the headers. 
If the method is POST, terminator is set to the number of bytes to read
(the content-length header), and found_terminator is set to handle_post_data

After that, the handle_data() method is called and the connection is closed

Subclasses of RequestHandler only have to override the handle_data() method
"""

import asynchat, asyncore, socket, SimpleHTTPServer, select, urllib
import posixpath, sys, cgi, cStringIO, os, traceback, shutil

from json import dumps
from constants import RECV_BUFFER_SIZE, SEND_BUFFER_SIZE, STREAM_BUFFER_PIECES
from logger import log
from torrent import Torrent

class TorrentStream(object):
    def __init__(self, rfile, wfile, torrent, first, last):
        self.rfile = rfile
        self.wfile = wfile
        self.torrent = torrent
        self.file = torrent.downloader.file
        self.start_piece = torrent.get_piece_from_offset(self.file, first)
        self.end_piece = torrent.get_piece_from_offset(self.file, last)
        self.first = first
        self.last = last
        self._piece = self.start_piece
        self._left = last - first + 1
        self._buffering = False
        self.init()
        
    def init(self):
        new_pieces = []
        for piece_index in range(self.start_piece, self.end_piece + 1, 1):
            if not self.torrent.has_piece(piece_index):
                new_pieces.append(piece_index)
                
        self.torrent.downloader.pieces_first = new_pieces + self.torrent.downloader.pieces_first
        #log(self.torrent.downloader.pieces_first)
        
    def buffer(self):
        buffer_pieces = max(1024*1024/self.torrent.piece_length, STREAM_BUFFER_PIECES) # TODO: check convenience when pieces are too small
        for piece_index in range(self._piece, min(self._piece + buffer_pieces, self.end_piece + 1) , 1):
            while not self.torrent.has_piece(piece_index):
                sleep(0.1)
                
        self._buffering = False
                
    def push(self):
        while self._left > 0:
            if self.torrent.has_piece(self._piece):
                if self._piece == self.start_piece:
                    self.rfile.seek(self.first)
                    read_length = self.torrent.piece_length - (self.file['begin_offset'] + self.first - self.start_piece * self.torrent.piece_length)
                else:
                    read_length = min(self.torrent.piece_length, self._left)
                log('reading piece %d bytes %d' % (self._piece, read_length))
                buffer = self.rfile.read(read_length)
                if buffer:
                    self.wfile.write(buffer)
                    self._left -= len(buffer)
                    self._piece += 1
                else:
                    log('no buffer available')
                    break
            elif not self._buffering:
                self._buffering = True
                self.buffer()

class CI_dict(dict):
    """Dictionary with case-insensitive keys
    Replacement for the deprecated mimetools.Message class
    """

    def __init__(self, infile, *args):
        self._ci_dict = {}
        lines = infile.readlines()
        for line in lines:
            k,v=line.split(":",1)
            self._ci_dict[k.lower()] = self[k] = v.strip()
        self.headers = self.keys()
    
    def getheader(self,key,default=""):
        return self._ci_dict.get(key.lower(),default)
    
    def get(self,key,default=""):
        return self._ci_dict.get(key.lower(),default)
    
    def __getitem__(self,key):
        return self._ci_dict[key.lower()]
    
    def __contains__(self,key):
        return key.lower() in self._ci_dict
        
class socketStream:
    def __init__(self, sock):
        """Initiate a socket (non-blocking) and a buffer"""
        self.sock = sock
        self.buffer = cStringIO.StringIO()
        self.closed = 1   # compatibility with SocketServer
    
    def write(self, data):
        """Buffer the input, then send as many bytes as possible"""
        self.buffer.write(data)
        if self.writable():
            buff = self.buffer.getvalue()
            # next try/except clause suggested by Robert Brown
            try:
                    sent = self.sock.send(buff)
            except:
                    # Catch socket exceptions and abort
                    # writing the buffer
                    sent = len(data)

            # reset the buffer to the data that has not yet be sent
            self.buffer=cStringIO.StringIO()
            self.buffer.write(buff[sent:])
            
    def finish(self):
        """When all data has been received, send what remains
        in the buffer"""
        data = self.buffer.getvalue()
        # send data
        while len(data):
            while not self.writable():
                pass
            sent = self.sock.send(data)
            data = data[sent:]

    def writable(self):
        """Used as a flag to know if something can be sent to the socket"""
        result = False
        try:
            result = select.select([],[self.sock],[])[1]
        except:
            pass
        return result

class RequestHandler(asynchat.async_chat,
    SimpleHTTPServer.SimpleHTTPRequestHandler):

    protocol_version = "HTTP/1.1"
    MessageClass = CI_dict

    def __init__(self,conn,addr,server):
        asynchat.async_chat.__init__(self,conn)
        self.client_address = addr
        self.connection = conn
        self.server = server
        # set the terminator : when it is received, this means that the
        # http request is complete ; control will be passed to
        # self.found_terminator
        self.set_terminator ('\r\n\r\n')
        self.rfile = cStringIO.StringIO()
        self.found_terminator = self.handle_request_line
        self.request_version = "HTTP/1.1"
        # buffer the response and headers to avoid several calls to select()
        self.wfile = cStringIO.StringIO()

    def collect_incoming_data(self,data):
        """Collect the data arriving on the connexion"""
        self.rfile.write(data)

    def prepare_POST(self):
        """Prepare to read the request body"""
        bytesToRead = int(self.headers.getheader('content-length'))
        # set terminator to length (will read bytesToRead bytes)
        self.set_terminator(bytesToRead)
        self.rfile = cStringIO.StringIO()
        # control will be passed to a new found_terminator
        self.found_terminator = self.handle_post_data
    
    def handle_post_data(self):
        """Called when a POST request body has been read"""
        self.rfile.seek(0)
        self.do_POST()
        self.finish()

    def send_stream(self, file, first, last):
        torrent = self.server.torrent_server.torrent
        stream = TorrentStream(file, self.wfile, torrent, first, last)
        stream.push()
        
    def do_HEAD(self):
        print 'do_HEAD'
        file, range = self.send_head()
        if file:
            file.close()
        
    def do_GET(self):
        print 'do_GET'
        """Begins serving a GET request"""
        # nothing more to do before handle_data()
        self.body = {}
        self.handle_data()
        
    def do_POST(self):
        """Begins serving a POST request. The request data must be readable
        on a file-like object called self.rfile"""
        ctype, pdict = cgi.parse_header(self.headers.getheader('content-type'))
        self.body = cgi.FieldStorage(fp=self.rfile,
            headers=self.headers, environ = {'REQUEST_METHOD':'POST'},
            keep_blank_values = 1)
        self.handle_data()

    def handle_request_line(self):
        """Called when the http request line and headers have been received"""
        # prepare attributes needed in parse_request()
        self.rfile.seek(0)
        self.raw_requestline = self.rfile.readline()
        self.parse_request()

        if self.command in ['GET','HEAD']:
            # if method is GET or HEAD, call do_GET or do_HEAD and finish
            method = "do_"+self.command
            if hasattr(self,method):
                getattr(self,method)()
                self.finish()
        elif self.command=="POST":
            # if method is POST, call prepare_POST, don't finish yet
            self.prepare_POST()
        else:
            self.send_error(501, "Unsupported method (%s)" %self.command)

    def end_headers(self):
        """Send the blank line ending the MIME headers, send the buffered
        response and headers on the connection, then set self.wfile to
        this connection
        This is faster than sending the response line and each header
        separately because of the calls to select() in socketStream"""
        if self.request_version != 'HTTP/0.9':
            self.wfile.write("\r\n")
        self.start_resp = cStringIO.StringIO(self.wfile.getvalue())
        self.wfile = socketStream(self.connection)
        self.copyfile(self.start_resp, self.wfile)

    def handle_error(self):
        traceback.print_exc(sys.stderr)
        self.close()

    def copyfile(self, source, outputfile):
        """Copy all data between two file objects
        Set a big buffer size"""
        shutil.copyfileobj(source, outputfile, length = 128*1024)

    def finish(self):
        """Send data, then close"""
        try:
            self.wfile.finish()
        except AttributeError: 
            # if end_headers() wasn't called, wfile is a StringIO
            # this happens for error 404 in self.send_head() for instance
            self.wfile.seek(0)
            self.copyfile(self.wfile, socketStream(self.connection))
        self.close()

    def send_head(self):
        range = None
        file = None
        file_path = None
        file_len = 0
        file_time = 0
        json_response = ''
        
        request_path, request_params = self.parse_request_path(self.path)
        
        if request_path == '/retr': # RETR TORRENT
            torrent_dir = urllib.unquote(request_params['path']) if 'path' in request_params else None
            torrent_file = urllib.unquote(request_params['file']) if 'file' in request_params else None
            if torrent_file:
                if self.server.torrent_server.torrent:
                    log('stopping thread')
                    self.server.torrent_server.torrent.stop()
                    self.server.torrent_server.torrent = None
                self.server.torrent_server.torrent = Torrent()
                self.server.torrent_server.torrent.start(torrent_file, torrent_dir)	
                json_response = dumps(self.server.torrent_server.torrent.files)
            self.send_json_response(json_response)
        elif request_path == '/down': # DOWN FILE
            torrent_dir = urllib.unquote(request_params['path']) if 'path' in request_params else None
            file_index = int(request_params['index']) if 'index' in request_params and request_params['index'].isdigit() else 0
            if self.server.torrent_server.torrent and file_index < len(self.server.torrent_server.torrent.files):
                self.server.torrent_server.torrent.download(file_index, torrent_dir, True)				
                json_response = dumps(self.server.torrent_server.torrent.files[file_index])
            self.send_json_response(json_response)
        elif request_path == '/info': # INFO FILE
            if self.server.torrent_server.torrent and self.server.torrent_server.torrent.downloader:
                json_response = dumps({'ready':True, 'files':self.server.torrent_server.torrent.files, 'name': self.server.torrent_server.torrent.downloader.file['name'], 'path':self.server.torrent_server.torrent.downloader.get_file_path(), 'length':self.server.torrent_server.torrent.downloader.file['length'], 'downloaded': self.server.torrent_server.torrent.downloader.downloaded_bytes, 'progress':self.server.torrent_server.torrent.downloader.downloaded_percent, 'speed':self.server.torrent_server.torrent.downloader.download_speed, 'active_peers': len(self.server.torrent_server.torrent.downloader.active_peers), 'total_peers': len(self.server.torrent_server.torrent.downloader.started_peers)})
            elif self.server.torrent_server.torrent:
                json_response = dumps({'ready':False, 'files':self.server.torrent_server.torrent.files})
            else:
                json_response = dumps({'ready':False})
            self.send_json_response(json_response)
        elif request_path == '/play': # PLAY FILE
            file_path = urllib.unquote(request_params['file']) if 'file' in request_params else None
            file_path = self.server.torrent_server.torrent.downloader.get_file_path() if not file_path and self.server.torrent_server and self.server.torrent_server.torrent and self.server.torrent_server.torrent.downloader and self.server.torrent_server.torrent.downloader.get_file_path() else file_path
            file_len = self.server.torrent_server.torrent.downloader.file['length'] if self.server.torrent_server and self.server.torrent_server.torrent and self.server.torrent_server.torrent.downloader and self.server.torrent_server.torrent.downloader.file and 'length' in self.server.torrent_server.torrent.downloader.file else 0
            log('file is %s' % file_path)
            try:
                file = open(file_path, 'rb')
                fs = fstat(file.fileno())
                file_len = fs[6] if not file_len else file_len
                file_time = fs.st_mtime
                file_type = guess_type(file_path)[0]
            except IOError:
                self.send_error(404, 'File not found')
                return file, range
            
            if 'Range' in self.headers:
                log('Range requested %s' % self.headers['Range'])
                try:
                    range = self.parse_range(self.headers['Range'])
                except ValueError as e:
                    self.send_error(400, 'Invalid byte range')
                    return file, range
                
                first, last = range				
                if first >= file_len:
                    self.send_error(416, 'Requested range not satisfiable')
                    return file, None
    
                if last is None or last >= file_len:
                    last = file_len - 1
                response_length = last - first + 1
    
                range = first, last
                
                log('type: %s  bytes: %d-%d/%d' % (file_type, first, last, file_len))
                
                self.send_response(206)
                self.send_header('Content-Type', file_type)
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Content-Range', 'bytes %d-%d/%d' % (first, last, file_len))
                self.send_header('Content-Length', str(response_length))
                self.send_header('Last-Modified', str(rfc822.formatdate(file_time)))
                self.end_headers()
            else:
                self.send_response(200)
                self.send_header('Content-Type', file_type)
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Content-Length', str(file_len))
                self.send_header('Last-Modified', str(rfc822.formatdate(file_time)))
                self.end_headers()
        elif request_path == '/stop': # STOP TORRENT
            if self.server.torrent_server.torrent:
                log('stopping thread')
                self.server.torrent_server.torrent.stop()
                self.server.torrent_server.torrent = None
        else:
            self.send_json_response(json_response)
        
        return file, range
    
    def send_json_response(self, data=None):
        self.send_response(200)
        if data and len(data) > 0:
            self.send_header('Content-type', 'application/json')
            self.send_header('Content-length', '%d' % len(data))
            self.end_headers()
            self.wfile.write(data)
        else:
            self.end_headers()
        
    def parse_request_path(self, full_path):
        request_path = None
        request_params = {}
        if '?' in full_path:
            split_path = full_path.split('?')
            request_path = split_path[0]
            if len(split_path) > 1:
                split_params = split_path[1].split('&')
                for param in split_params:
                    if '=' in param:
                        split_param = param.split('=')
                        if len(split_param) > 1:
                            request_params[split_param[0]] = split_param[1]
        else:
            request_path = full_path
            
        return request_path, request_params
    
    def parse_range(self, byte_range):
        BYTE_RANGE_RE = re.compile(r'bytes=(\d+)-(\d+)?$')
        if byte_range.strip() == '':
            return None, None
        
        m = BYTE_RANGE_RE.match(byte_range)
        if not m:
            raise ValueError('Invalid byte range %s' % byte_range)
        
        first, last = [x and int(x) for x in m.groups()]
        if last and last < first:
            raise ValueError('Invalid byte range %s' % byte_range)
        
        return first, last
        
    def handle_data(self):
        """Class to override"""
        file, range = self.send_head()
        if file:
            try:
                if range: # need to make range global
                    first, last = range 
                    self.send_stream(file, first, last)
                else:
                    shutil.copyfileobj(file, self.wfile)
            finally:
                file.close()
        
class Server(asyncore.dispatcher):
    """Copied from http_server in medusa"""
    def __init__ (self, ip='', port=8080, handler=RequestHandler):
        self.ip = ip
        self.port = port
        self.handler = handler
        self.torrent = None
        self.torrent_server = self
        asyncore.dispatcher.__init__ (self)
        self.create_socket (socket.AF_INET, socket.SOCK_STREAM)

        self.set_reuse_addr()
        self.bind ((ip, port))

        # lower this to 5 if your OS complains
        self.listen (1024)

    def handle_accept (self):
        try:
            conn, addr = self.accept()
        except socket.error:
            self.log_info('warning: server accept() threw an exception', 'warning')
            return
        except TypeError:
            self.log_info('warning: server accept() threw EWOULDBLOCK', 'warning')
            return
        # creates an instance of the handler class to handle the request/response
        # on the incoming connexion
        self.handler(conn,addr,self)
        self.handler.server = self

if __name__=="__main__":
    # launch the server on the specified port
    port = 8081
    s=Server('',port,RequestHandler)
    print "SimpleAsyncHTTPServer running on port %s" %port
    try:
        asyncore.loop(timeout=2)
    except KeyboardInterrupt:
        print "Crtl+C pressed. Shutting down."
