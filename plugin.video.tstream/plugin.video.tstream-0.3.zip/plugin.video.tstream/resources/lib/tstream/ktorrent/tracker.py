import asyncore
import socket
from scheduler import CallLater
from random import randrange
from urllib import unquote, urlencode
from urlparse import urlparse
from StringIO import StringIO
from struct import pack, unpack, unpack_from
from bencode import bencode, bdecode
from constants import RECV_BUFFER_SIZE, TRACKER_PEER_COUNT, TRACKER_TIMEOUT
from logger import log

class Tracker(object):
	def __init__(self, downloader, uri, params, callback=None):
		self.downloader = downloader
		self.uri = uri
		self.params = params
		self.callback = callback
		self.tracker = self.get_tracker()
		self.peers = []
	
	def get_tracker(self):
		tracker = None
		parsed_uri = urlparse(self.uri)
		host = parsed_uri.hostname
		port = parsed_uri.port if parsed_uri.port else 80
		path = parsed_uri.path
		if self.uri.startswith('http://') or self.uri.startswith('https://'):
			tracker = TcpTracker(self, host, port, path, self.params)
		elif self.uri.startswith('udp://'):
			tracker = UdpTracker(self, host, port, path, self.params)
		return tracker			
		
	def add_peer(self, peer):
		if not peer in self.peers:
			self.peers.append(peer)
		if self.callback:
			self.callback(peer)
		
class TcpTracker(asyncore.dispatcher):
	def __init__(self, tracker, host, port, path, params):
		asyncore.dispatcher.__init__(self)
		self.tracker = tracker
		self.host = host
		self.port = port
		self.path = path
		self.params = params
		self.buffer = None
		self.peers = []
		self.connected = False
		try:
			self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
			self.connect((self.host, self.port))
			self.callback = CallLater(TRACKER_TIMEOUT, self.handle_close)
		except:	
			log('ERROR CONNECTING TO TRACKER %s:%d' % (self.host, self.port))
			self.close()
		
	def handle_connect(self):
		log('CONNECTED TO TRACKER %s:%d' % (self.host, self.port))
		self.connected = True
		self.callback.cancel()
		request = 'GET %s?%s HTTP/1.0\r\n\r\n' % (self.path, urlencode(self.params, True))
		self.send(request)
		
	def handle_close(self):
		self.close()
	
	def handle_read(self):
		#log('RECEIVED RESPONSE FROM TRACKER %s:%d' % (self.host, self.port))
		if not self.buffer:
			self.buffer = self.recv(RECV_BUFFER_SIZE)
		else:
			self.buffer += self.recv(RECV_BUFFER_SIZE)
		try:
			headers, headers_length, content = self.parse_http(self.buffer)
			header_value = self.header_value(headers, 'Content-Length:')
			if header_value and header_value.isdigit():
				content_length = int(header_value)
				if len(content) >= content_length:
					headers, headers_length, content = self.parse_http(self.buffer)
					self.parse_response(content)
					self.buffer = self.buffer[(headers_length+content_length):]
		except:
			log('ERROR IN RESPONSE FROM %s:%d' % (self.host, self.port))
	
	def parse_response(self, response):
		decoded_response = bdecode(response)
		if 'peers' in decoded_response or 'peers6' in decoded_response:
			peer_list = decoded_response['peers'] if 'peers' in decoded_response else decoded_response['peers6']
			if isinstance(peer_list, list): # DICTIONARY
				for peer_dict in peer_list:
					self.tracker.add_peer((peer_dict['ip'], peer_dict['port']))
			else: # BINARY
				ip_length = 6 if 'peers' in decoded_response else 18
				peer_bin = [peer_list[i:i+ip_length] for i in range(0, len(peer_list), ip_length)]
				for peer in peer_bin:
					ip = '.'.join(str(ord(i)) for i in peer[:ip_length-2])
					port = ord(peer[ip_length-2])*256 + ord(peer[ip_length-1])
					self.tracker.add_peer((ip, port))
			
	def parse_http(self, data):
		headers = []
		contents = None
		headers_length = 0
		lines = StringIO(data)
		line = lines.readline()
		while line and line not in ['\n', '\r\n']:
			headers.append(line)
			headers_length += len(line)
			line = lines.readline()
		headers_length += len(line)
		lines.close()
		content = data[headers_length:]
		return headers, headers_length, content
	
	def header_value(self, headers, header_name):
		value = None
		for header in headers:
			if header.startswith(header_name):
				value = header[len(header_name):].strip(' \r\n')
				break
		return value		
		
class UdpTracker(asyncore.dispatcher):
	def __init__(self, tracker, host, port, path, params):
		asyncore.dispatcher.__init__(self)
		self.tracker = tracker
		self.host = host
		self.port = port
		self.path = path
		self.params = params
		self.transaction_id = None
		self.connection_id = None
		self.peers = []
		self.connected = False
		try:
			self.create_socket(socket.AF_INET, socket.SOCK_DGRAM)
			self.connect((self.host, self.port))
			self.callback = CallLater(TRACKER_TIMEOUT, self.handle_close)
		except:	
			log('ERROR CONNECTING TO TRACKER %s:%d' % (self.host, self.port))
			self.close()			
	
	def handle_connect(self):
		log('CONNECTED TO TRACKER %s:%d' % (self.host, self.port))
		self.connected = True
		self.callback.cancel()
		request = self.connection_request()
		self.send(request)
		
	def handle_close(self):
		self.close()
	
	def handle_read(self):
		buffer = self.recv(RECV_BUFFER_SIZE)
		response = self.parse_response(buffer)
		if self.connection_id and not response:
			self.send(self.announce_request(self.params))
		elif response and 'peers' in response:
			for peer in response['peers']:
				ip = socket.inet_ntoa(pack('!i',int(peer['ip'])))
				port = int(peer['port'])
				self.tracker.add_peer((ip, port))
	
	def get_transaction_id(self):
		return int(randrange(0, 255))
	
	def connection_request(self):
		connection_id = 0x41727101980 						#default connection id
		action = 0x0 										#action (0 = give me a new connection id)	
		self.transaction_id = self.get_transaction_id()			#new transaction in
		request = pack('!q', connection_id) 			#first 8 bytes is connection id
		request += pack('!i', action) 				#next 4 bytes is action
		request += pack('!i', self.transaction_id) 	#next 4 bytes is transaction id
		return request

	def announce_request(self, params, s_port=None):
		action = 0x1 #action (1 = announce)
		self.transaction_id = self.get_transaction_id()
		request = pack('!q', self.connection_id) 					#first 8 bytes is connection id
		request += pack('!i', action) 								#next 4 bytes is action 
		request += pack('!i', self.transaction_id) 					#followed by 4 byte transaction id
		request += pack('!20s', unquote(params['info_hash'])) 		#the info hash of the torrent we announce ourselves in
		request += pack('!20s', unquote(params['peer_id']).encode())#the peer_id we announce
		request += pack('!q', int(params['downloaded'])) 			#number of bytes downloaded
		request += pack('!q', int(params['left']))					#number of bytes left
		request += pack('!q', int(params['uploaded'])) 				#number of bytes uploaded
		request += pack('!i', 0x2) 									#event 2 denotes start of downloading
		request += pack('!i', 0x0) 									#IP address set to 0. Response received to the sender of this packet 								
		request += pack('!i', self.get_transaction_id())			#Unique key randomized by client
		request += pack('!i', TRACKER_PEER_COUNT) 					#Number of peers required. Set to -1 for default
		request += pack('!i', int(params['port'])) 	 				#port on which response will be sent
		# request += pack("!i", int(s_port)) 	 					#port on which response will be sent
		return request		
	
	def parse_response(self, data):
		ret_value = None
		if len(data) < 8:
			log('WRONG RESPONSE LENGTH %d' % len(data))
		else:
			action = unpack_from('!i', data)[0] #first 4 bytes is action
			#log('ACTION %d' % action)
			transaction_id = unpack_from('!i', data, 4)[0] #next 4 bytes is transaction id	
			if transaction_id != self.transaction_id:
				log('TRANSACTION IDS DO NOT MATCH %s != %s' % (self.transaction_id, transaction_id))
			if action == 0x0:
				self.connection_id = unpack_from('!q', data, 8)[0] #unpack 8 bytes from byte 8, should be the connection_id
			elif action == 0x1:
				log('PEER LIST RECEIVED')
				ret_value = dict()
				offset = 8; 
				#next 4 bytes after action is transaction_id, so data doesnt start till byte 8		
				ret_value['interval'] = unpack_from("!i", data, offset)[0]
				offset += 4
				ret_value['leeches'] = unpack_from("!i", data, offset)[0]
				offset += 4
				ret_value['seeds'] = unpack_from("!i", data, offset)[0]
				offset += 4
				log('seeds: %d leeches: %d interval: %d' % (ret_value['seeds'],ret_value['leeches'],ret_value['interval']))
				ret_value['peers'] = list()
				x = 0
				while offset != len(data):
					ret_value['peers'].append(dict())
					ret_value['peers'][x]['ip'] = unpack_from('!i',data,offset)[0]
					offset += 4
					if offset >= len(data):
						log('ERROR READING PEER PORT')
					ret_value['peers'][x]['port'] = unpack_from('!H',data,offset)[0]
					offset += 2
					x += 1
			elif action == 0x2:
				log('SCRAPE RECEIVED')
			elif action == 0x3:
				error = unpack_from('!s', data, 8)
				log('ERROR GETTING CONNECTION RESPONSE: %s' % error)
			else:
				error = unpack_from('!s', data, 8)
				log('ERROR: %s' % error)
		
		return ret_value