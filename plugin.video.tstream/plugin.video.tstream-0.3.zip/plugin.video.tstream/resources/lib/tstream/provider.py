 # coding: latin-1
import re
import xbmc
import xbmcaddon
import urllib2
from urllib import quote, quote_plus, urlencode
from urlparse import urljoin
from cookielib import CookieJar

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')

USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.66 Safari/537.36"
COOKIES = CookieJar()

urllib2.install_opener(urllib2.build_opener(urllib2.HTTPCookieProcessor(COOKIES)))

class closing(object):
    def __init__(self, thing):
        self.thing = thing
    def __enter__(self):
        return self.thing
    def __exit__(self, *exc_info):
        self.thing.close()


def parse_json(data):
    try:
        import simplejson as json
    except ImportError:
        import json
    return json.loads(data)


def parse_xml(data):
    import xml.etree.ElementTree as ET
    return ET.fromstring(data)


def request(url, params={}, headers={}, data={}, method=None):
    if params:        
        url = "".join([url, "?", urlencode(params)])

    req = urllib2.Request(url)
    if method:
        req.get_method = lambda: method
    req.add_header("User-Agent", USER_AGENT)
    req.add_header("Accept-Encoding", "gzip")
    for k, v in headers.items():
        req.add_header(k, v)
    if data:
        req.add_data(data)
    try:
        with closing(urllib2.urlopen(req)) as response:
            data = response.read()
            if response.headers.get("Content-Encoding", "") == "gzip":
                import zlib
                data = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(data)
            response.data = data
            response.json = lambda: parse_json(data)
            response.xml = lambda: parse_xml(data)
            return response
    except (urllib2.ValueError, urllib2.HTTPError) as e:
        #xbmc.log("http error: %s => %d %s" % (url, e.code, e.reason))
        return None

HEAD = lambda *args, **kwargs: request(*args, method="HEAD", **kwargs)
GET = lambda *args, **kwargs: request(*args, method="GET", **kwargs)
POST = lambda *args, **kwargs: request(*args, method="POST", **kwargs)
PUT = lambda *args, **kwargs: request(*args, method="PUT", **kwargs)
DELETE = lambda *args, **kwargs: request(*args, method="DELETE", **kwargs)


def append_headers(uri, headers):
    return uri + "|" + "|".join(["%s=%s" % h for h in headers.items()])


def with_cookies(uri):
    return uri + "|Cookies=" + "; ".join(["%s=%s" % (c.name, c.value) for c in COOKIE_JAR])

    
def reMatch(text, pattern, index=1, clean=True):
    reMatch = re.match(pattern, text, re.S)
    if reMatch:
        retValue = cleanHtml(reMatch.group(index)) if clean else reMatch.group(index)
        while retValue.find('\t')>=0:
            retValue = retValue.replace('\t',' ')
        return retValue.strip(' \t\n\r') if retValue else retValue
    else:
        return None

        
def reSearch(text, pattern, index=1, clean=True):
    reSearch = re.search(pattern, text, re.S)
    if reSearch:        
        #xbmc.log('PATTERN %s GROUPS ARE %d' % (pattern, len(reSearch.groups())))
        group = reSearch.group(index) if reSearch.group(index) else reSearch.group(len(reSearch.groups()))
        retValue = cleanHtml(group) if clean else group
        while retValue.find('\t')>=0:
            retValue = retValue.replace('\t',' ')
        return retValue.strip(' \t\n\r') if retValue else retValue
    else:
        return None
    
    
def extractItems(text, pattern):
    items = []
    reFindAll = re.findall(pattern, text, re.S)
    for item in reFindAll:
        items.append(item)
    return items
    

def extractMagnets(data):    
    return extractItems(data, r'magnet:\?[^\'"\s<>\[\]]+', False)
        
        
def getItemsFromPattern(uri, patterns, page_pattern=None, is_playable=True, callback=None):
    items = []
    if 'item' in patterns and 'path' in patterns:
        if uri.startswith('POST@'):
            uri = uri[len('POST@'):]
            if uri.find('?') >= 0:
                params = uri.split('?')[1]
            else:
                params = None            
            response = POST(uri, data=params)
        else:
            response = GET(uri)
            
        if response:            
            results = extractItems(response.data, patterns['item'])
            for result in results:
                #xbmc.log('ITEM %s' % result)
                item = {}
                item['infoLabels'] = {}
                for pattern in patterns:
                    if pattern in ['label', 'label2', 'path', 'icon', 'thumbnail', 'is_playable']:
                        #xbmc.log('[%s]=%s' % (pattern, patterns[pattern]))
                        item[pattern] = reSearch(result, patterns[pattern])
                        #xbmc.log('[%s]=%s -> %s' % (pattern, patterns[pattern], item[pattern]))
                        if pattern in ['icon', 'thumbnail']:
                            item[pattern] = getSanitizedLink(uri, item[pattern])
                    elif pattern not in ['item', 'base']:
                        #xbmc.log('[%s]=%s' % (pattern, patterns[pattern]))
                        item['infoLabels'][pattern] = reSearch(result, patterns[pattern])      
                        #xbmc.log('[%s]=%s -> %s' % (pattern, patterns[pattern], item['infoLabels'][pattern]))
                    if 'base' in patterns and pattern in ['icon', 'thumbnail']:                        
                        item[pattern] = '%s/%s' % (patterns['base'], item[pattern])
                        item[pattern] = item[pattern].replace(' ','%20') # fix for links with spaces
                
                if not item['infoLabels']:
                    item['infoLabels'] = item['path']
                
                item['is_playable'] = is_playable
                if callback:                     
                    item['callback'] = callback
                    item['args'] = item['path']                    
                
                if 'label' in item and item['label'] and 'path' in item and item['path']:
                    items.append(ensureItemConsistency(item))
            
            if len(items) > 0 and page_pattern:
                items.append(getDirectory(args=getNextPage(uri, page_pattern)))
                
    return items

def getInfoLabelsFromPattern(uri, patterns):
    infoLabels = {}
    if uri.startswith('POST@'):
        uri = uri[len('POST@'):]
        if uri.find('?') >= 0:
            params = uri.split('?')[1]
        else:
            params = None
        response = POST(uri, data=params)
    else:
        response = GET(uri)
        
    if response:
        result = response.data
        for pattern in patterns:
            try:                
                #xbmc.log('[%s]=%s' % (pattern, patterns[pattern]))                                        
                infoLabels[pattern] = cleanHtml(reSearch(result, patterns[pattern])) #.decode('utf-8', 'ignore').encode('utf-8', 'ignore')
                while infoLabels[pattern].find('  ')>=0:
                    infoLabels[pattern] = infoLabels[pattern].replace('  ',' ')
                #xbmc.log('[%s]=%s -> %s' % (pattern, patterns[pattern], infoLabels[pattern]))
                if pattern == 'year':
                    infoLabels[pattern] = int(infoLabels[pattern])
                elif pattern == 'rating':
                    infoLabels[pattern] = float(infoLabels[pattern])
                elif pattern == 'cast':
                    infoLabels[pattern] = infoLabels[pattern].split(', ')
            except:
                pass

    return infoLabels
                    
def getNextPage(uri, pattern):
    page = 1
    reMatch = re.search(pattern, uri)
    if reMatch:        
        page = int(reMatch.group(1))
        uri = '%s%d%s' % (uri[:reMatch.start(1)],page+1,uri[reMatch.end(1):])
    
    #xbmc.log('NEXT PAGE IS %s' % uri)
    return uri
    
def cleanHtml(text):    
    reCompile = re.compile('<.*?>')
    cleanText = re.sub(reCompile, '', text)
    return replaceHTML(cleanText)

def replaceHTML(text):
    html_escape_table = {
    "&Aacute;": "A",
    "&Eacute;": "E",
    "&Iacute;": "I",
    "&Oacute;": "O",
    "&Uacute;": "U",
    "&aacute;": "a",
    "&eacute;": "e",
    "&iacute;": "i",
    "&oacute;": "o",
    "&uacute;": "u",
    }
    for k,v in html_escape_table.items():
        if k in text:
            text = text.replace(k, v)
    
    return text
    
def ensureItemConsistency(item):
    if not 'label' in item:
        item['label'] = ''
    else:
        item['label'] = item['label'].decode('utf-8', 'ignore').encode('utf-8', 'ignore')
    if not 'label2' in item:
        item['label2'] = ''
    else:
        item['label2'] = item['label2'].decode('utf-8', 'ignore').encode('utf-8', 'ignore')
    if not 'is_playable' in item:
        item['is_playable'] = True
    if not 'icon' in item:
        item['icon'] = 'DefaultVideo.png' if item['is_playable'] else ''
    if not 'thumbnail' in item:
        item['thumbnail'] = 'DefaultVideo.png' if item['is_playable'] else ''
    if not 'path' in item:
        item['path'] = ''
        
    return item
   
def getItem(label='', label2='', icon='', thumbnail='', isPlayable=False, path='', callback=None, args=None):
    item = {}
    item['label'] = label.decode('utf-8', 'ignore').encode('utf-8', 'ignore')
    item['label2'] = label2.decode('utf-8', 'ignore').encode('utf-8', 'ignore')
    item['icon'] = icon
    item['thumbnail'] = thumbnail
    item['is_playable'] = isPlayable
    item['path'] = path
    item['callback'] = callback
    item['args'] = quote(args) if args else None
    
    return item

def getSanitizedLink(base_url, link):
    return urljoin(base_url, link)
    
def getDirectory(label='>', label2='', icon='DefaultFolder.png', thumbnail='DefaultFolder.png', isPlayable=False, path='', callback=None, args=None):    
    return getItem(label, label2, icon, thumbnail, isPlayable, path, callback, args)


def getMenuItem(label='', callback=None, args=None):
    return getItem(label=label,callback=callback, args=args)
    
    
def getTypeFromTitle(title):    
    reMatch = re.match(r'(.*?)[\-\ ]*?([0-9]+x[0-9]+|s[0-9]+e[0-9]+)', title.strip(), re.I)
    if reMatch:
        return 'tv'
    else:
        return 'movie'
    
    
def getCleanTvTitle(title, index=0):    
    cleanTitle = title.strip().lower()
    reMatch = re.search(r'(.*?)[\-\ ]*?([0-9]+x[0-9]+|s[0-9]+e[0-9]+)', cleanTitle, re.I)
    if reMatch:
        cleanTitle = reMatch.group(index)
                
    cleanTitle = cleanTitle.strip()
        
    return cleanTitle

    
def getCleanMovieTitle(title, index=0):    
    cleanTitle = title.strip().lower()
    reMatch = re.search(r'(.*?)\s*(?:(19|20)\d{2}|\(.*?\))', cleanTitle, re.I)
    if reMatch:
        cleanTitle = reMatch.group(index)
                
    cleanTitle = cleanTitle.strip()
        
    return cleanTitle

    
def getCleanTitle(title, index=0):
    cleanTitle = None    
    type = getTypeFromTitle(title)                
    
    if type == 'tv':
        cleanTitle = getCleanTvTitle(title, index)
    else:
        cleanTitle = getCleanMovieTitle(title, index)        
    
    cleanTitle.replace('-', '')
    cleanTitle.replace('  ',' ')
    
    return cleanTitle
    
def getMovieInfo(query, language='es', type=None):
    import json
    from random import randint
    API_KEYS = ['4be68d7eab1fbd1b6fd8a3b80a65a95e', '5c235bb1b487932ebf0a9935c8b39b0a', '8d0e4dca86c779f4157fc2c469c372ca']    
    item = None
    
    if not type: type = getTypeFromTitle(query)    
    
    #xbmc.log('TYPE OF %s IS %s' % (query, type))
    
    api_key = API_KEYS[randint(0,len(API_KEYS)-1)]
    
    tmdb_uri = 'http://api.themoviedb.org/3/search/%s?query=%s&language=%s&api_key=%s' % (type, quote_plus(query), language, api_key)        
    image_uri = 'http://image.tmdb.org/t/p/w500'    
    #xbmc.log(tmdb_uri)
    response = GET(tmdb_uri)
    
    if response:        
        jsonItems = json.loads(response.data)        
        if 'total_results' in jsonItems and int(jsonItems['total_results'])>0:
            jsonItem = jsonItems['results'][0]
            #xbmc.log(json.dumps(jsonItem))
            if 'title' in jsonItem and 'original_title' in jsonItem:
                label = jsonItem['title']
                label2 = jsonItem['original_title']
            elif 'name' in jsonItem and 'original_name' in jsonItem:
                label = jsonItem['name']
                label2 = jsonItem['original_name']
            else:
                label = ''
                label2 = ''
                                                
            item = {}
            item['label'] = label
            item['label2'] = label2
            item['icon'] = '%s%s' % (image_uri, jsonItem['poster_path']) if 'poster_path' in jsonItem else ''
            item['thumbnail'] = '%s%s' % (image_uri, jsonItem['poster_path']) if 'poster_path' in jsonItem else ''
            item['infoLabels'] = {}                       
            item['infoLabels']['plot'] = jsonItem['overview'] if 'overview' in jsonItem else ''
            item['infoLabels']['plotoutline'] = jsonItem['overview'] if 'overview' in jsonItem else ''                        
            item['infoLabels']['rating'] = jsonItem['vote_average'] if 'vote_average' in jsonItem else ''
    
    return item
