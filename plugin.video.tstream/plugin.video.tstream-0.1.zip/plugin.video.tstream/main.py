import xbmc, xbmcaddon
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
from tstream import navigation

ADDON = xbmcaddon.Addon()
CLEANUP = ADDON.getSetting('cleanup')
TORRENT_TEMP_DIR = ADDON.getSetting('temp_dir_path')

if CLEANUP:
    try:
        import shutil
        shutil.rmtree(os.path.join(TORRENT_TEMP_DIR,'*'))
    except:
        pass

navigation.run()
