import binary
import json
import os
import player
import provider
import urllib
import urllib2
import xbmc
import xbmcaddon
import xbmcgui

from ktorrent import server as kserver

LOOP_WAIT_MS = 200

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')

NODE_BINARY_PATH = ADDON.getSetting('node_binary_path')
TORRENT_BUFFER = float(ADDON.getSetting('buffer_percent'))
TORRENT_TEMP_DIR = ADDON.getSetting('temp_dir_path')
TORRENT_MOVE_DIR = ADDON.getSetting('move_dir_path')
TORRENT_SERVER = ADDON.getSetting('torrent_server_address')
TORRENT_DATA = '%s/data' % TORRENT_SERVER
TORRENT_RETR = '%s/retr' % TORRENT_SERVER
TORRENT_DOWN = '%s/down' % TORRENT_SERVER
TORRENT_INFO = '%s/info' % TORRENT_SERVER
TORRENT_PLAY = '%s/play' % TORRENT_SERVER
TORRENT_STOP = '%s/stop' % TORRENT_SERVER
TORRENT_STOP = '%s/exit' % TORRENT_SERVER
TORRENT_PROCESS = None

def sendRequest(url):
    content = ''
    try:
        response = urllib2.urlopen(url) 
        if response and response.getcode() == 200:
            content = response.read()
            if not content: content = '200'
        else:
            content = ''
        response.close()
    except urllib2.URLError:
        xbmc.log('Could not open URL %s' % url)        
    return content
        
def dialogCancel(dialog):
    dialog.close()      
    del dialog
    stop()

def startServer():     
    global TORRENT_PROCESS    
    if not sendRequest(TORRENT_SERVER):
        xbmc.log('Server not running, attempting to start...')
        node_path = ADDON.getAddonInfo('path')
        xbmc.log('NODE PATH IS: %s' % node_path)
        if node_path:
            node_dir = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'node')
            node_dir = node_dir.decode('latin1')
            args = os.path.join(node_dir, 'server.js')            
            if os.path.exists(NODE_BINARY_PATH):
                xbmc.log('Executing %s %s' % (NODE_BINARY_PATH, args))
                TORRENT_PROCESS = binary.runBinary(NODE_BINARY_PATH, args)
            else:
                TORRENT_PROCESS = binary.runBinary(None, args)
                xbmc.log('Node binary not found, please set correct path...')
        else:
            TORRENT_PROCESS = kserver.TorrentStreamServer()
            TORRENT_PROCESS.start(True)
           
    return TORRENT_PROCESS
                
def buffering(itemIndex):
    progressDownloaded = 0
    progressPercent = 0    
    progressSpeed = 0       
    progressDialog = xbmcgui.DialogProgress()       
    progressDialog.create('Buffering', '' , '%d K/s' % (progressSpeed))
    progressDialog.update(progressPercent, '' , 'P (0/0) @ %d K/s' % (progressSpeed))
    
    content = None
    while progressPercent < 100:    
        content = sendRequest(TORRENT_INFO)
        if content:
            jsonData = json.loads(content)
            if jsonData:                
                try:
                    if 'downloaded' in jsonData and ('length' in jsonData or 'totalLength' in jsonData):
                        itemName = jsonData['files'][itemIndex]['name']
                        itemLength = jsonData['files'][itemIndex]['length']
                        #progressSpeed = int(jsonData['downloadSpeed'])/1024
                        #progressDownloaded = float(jsonData['downloaded']) # float(jsonData['files'][itemIndex]['downloaded'])
                        progressSpeed = int(jsonData['speed']) if 'speed' in  jsonData else int(jsonData['downloadSpeed'])/1024
                        progressDownloaded = float(jsonData['downloaded']) if 'downloaded' in jsonData else float(jsonData['files'][itemIndex]['downloaded'])
                        #progressPercent = progressDownloaded/(float(jsonData['totalLength'])*TORRENT_BUFFER/10000)
                        progressPercent = progressDownloaded/(float(itemLength)*TORRENT_BUFFER/5000)
                        progressPercent = int(progressPercent) if progressPercent<100 else 100
                        activePeers = jsonData['active_peers'] if 'active_peers' in jsonData else jsonData['activePeers']
                        totalPeers = jsonData['total_peers'] if 'total_peers' in jsonData else jsonData['totalPeers']
                        progressDialog.update(progressPercent, itemName , 'P (%s/%s) @ %d K/s' % (activePeers, totalPeers, progressSpeed))
                        xbmc.log('Downloading %d/%d (%d%%) at %d K/s' % (progressDownloaded, itemLength, progressPercent, progressSpeed))
                        #xbmc.log('Downloading %d/%d (%d%%) at %d K/s' % (progressDownloaded, jsonData['totalLength'], progressPercent, progressSpeed))                    
                except:
                    pass
                    
                if progressDialog.iscanceled(): 
                    progressDialog.close()      
                    del progressDialog
                    stop()
                    return
        else:
            break
        xbmc.sleep(LOOP_WAIT_MS)    
        
    progressDialog.close()   
    del progressDialog

def play(torrent):
    global TORRENT_PROCESS
    if not TORRENT_PROCESS:    
        TORRENT_PROCESS = startServer()
    else:                
        stop()
            
    xbmc.sleep(LOOP_WAIT_MS)
        
    requestPath = '%s?file=%s' % (TORRENT_RETR, urllib.quote_plus(torrent))
    if TORRENT_TEMP_DIR: requestPath = '%s&path=%s' % (requestPath, urllib.quote_plus(TORRENT_TEMP_DIR))
    if TORRENT_MOVE_DIR: requestPath = '%s&move=%s' % (requestPath, urllib.quote_plus(TORRENT_MOVE_DIR))
    xbmc.log('Requesting %s' % requestPath)    
    
    itemIndex = None
    itemName = None
        
    content = None
    while not content:
        content = sendRequest(requestPath)    
    
    itemIndex = -1    
    itemDownloaded = 0
    itemLength = 0
    itemReady = False
    while itemIndex < 0 and itemReady == False:
        try:
            content = sendRequest(TORRENT_INFO)
            jsonData = None
            if content: jsonData = json.loads(content)
            if itemIndex < 0 and jsonData and 'files' in jsonData and jsonData['files']:
                if len(jsonData['files'])>1:
                    items = []
                    xbmc.log('Processing %d files' % len(jsonData['files']))
                    for file in jsonData['files']:
                        xbmc.log(file['name'].encode('utf8','ignore'))
                        items.append(file['name'])
                    selectDialog = xbmcgui.Dialog()
                    itemIndex = selectDialog.select('Select item to play', items)
                    if itemIndex < 0:
                        return
                else:
                    itemIndex = 0
            
            if itemIndex >= 0 and jsonData and 'files' in jsonData and jsonData['files']:
                itemName = jsonData['files'][itemIndex]['name']
                itemDownloaded = int(jsonData['files'][itemIndex]['downloaded'])
                itemLength = int(jsonData['files'][itemIndex]['length'])
                itemReady = jsonData['files'][itemIndex]['ready']
            
            xbmc.log('ITEM %d READY %d' % (itemIndex, itemReady))
        except:
            pass
        
        xbmc.sleep(LOOP_WAIT_MS)                
    
    sendRequest('%s?file=%d' % (TORRENT_DOWN, itemIndex))            
    xbmc.log('Download item %s?file=%d' % (TORRENT_DOWN, itemIndex))    
    
    if TORRENT_BUFFER > 0 and (itemLength == 0 or itemDownloaded < itemLength):
        buffering(itemIndex)
    
    return TORRENT_PLAY
    
def stop():
    if sendRequest(TORRENT_STOP):
        xbmc.log('Torrent stop requested')
        
def exit():
    if sendRequest(TORRENT_EXIT):
        xbmc.log('Torrent exit requested')