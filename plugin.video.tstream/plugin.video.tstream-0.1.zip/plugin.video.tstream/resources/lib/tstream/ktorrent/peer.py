import asyncore
import socket
from scheduler import CallLater
from struct import pack, unpack
from time import clock, time
from bitstring import BitArray
from constants import BLOCK_LENGTH, MIN_ACTIVE_PEERS, MIN_DOWNLOAD_SPEED, PEER_CONNECT_TIMEOUT, PEER_HANDSHAKE_TIMEOUT, PEER_MESSAGE_TIMEOUT, PEER_SPEED_THRESHOLD, RECV_BUFFER_SIZE
from logger import log
from messages import Messages

class Peer(asyncore.dispatcher):
	def __init__(self, downloader, ip, port):
		asyncore.dispatcher.__init__(self)
		self.ip = ip
		self.port = port
		self.downloader = downloader
		self.key = self.downloader.get_peer_key((self.ip, self.port))
		self.messages = Messages(downloader.torrent)
		self.buffer = ''
		self.handshake = False
		self.pieces_have = [False] * self.downloader.torrent.number_of_pieces
		self.pieces_interested = []
		self.blocks_requested = {}
		self.blocks_received = {}
		self.last_request = 1
		self.request_count = 0
		self.speed = 0
		self.state = {
				'am_choking' : True,
				'am_interested' : False,
				'peer_choking' : True,
				'peer_interested' : False,
		}
		self.started = False
		self.connected = False
		self.active = False
		self.valid = True
		self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
		self.timeout_callback = None
		
	def start(self):
		self.started = True
		try:
			self.timeout_callback = CallLater(PEER_CONNECT_TIMEOUT, self.handle_timeout)
			self.connect((self.ip, self.port))
		except:
			log('ERROR CONNECTING TO PEER %s:%d' % (self.ip, self.port))
			self.handle_close()
		
	def handle_timeout(self, args=None):
		self.handle_close()
		
	def handle_connect(self):
		#log('CONNECTED TO PEER %s:%d' % (self.ip, self.port))
		self.timeout_callback.delay(PEER_HANDSHAKE_TIMEOUT)
		self.connected = True
		self.send(self.messages.handshake())
	
	def handle_close(self):
		#log('DISCONNECTED FROM PEER %s:%d' % (self.ip, self.port))
		if self.timeout_callback:
			self.timeout_callback.cancel()
		self.connected = False
		self.valid = False
		self.close()
		self.downloader.del_peer((self.ip, self.port))
	
	def handle_read(self):
		#log('RECEIVED RESPONSE FROM PEER %s:%d' % (self.ip, self.port))
		self.buffer += self.recv(RECV_BUFFER_SIZE)
		
		if not self.buffer or len(self.buffer) == 0:
			self.handle_close()
		
		if not self.handshake:
			if len(self.buffer) >= 68:
				handshake_message = self.messages.handshake()
				if handshake_message[28:48] != self.buffer[28:48]:
					#log('HANDSHAKE ERROR WITH PEER %s:%d' % (self.ip, self.port))
					self.handle_close()
				else:
					#log('HANDSHAKE OK WITH PEER %s:%d' % (self.ip, self.port))
					#self.timeout_callback.delay(PEER_MESSAGE_TIMEOUT)
					self.timeout_callback.cancel()
					self.buffer = self.buffer[68:]
					self.handshake = True
					
		if self.handshake:
			if len(self.buffer) >= 4:
				#log('%s:%d at %d Kb/s delay %d' % (self.ip, self.port, self.speed, PEER_MESSAGE_TIMEOUT*(1+self.speed/10.0)))
				message_length = unpack('!L', self.buffer[:4])[0]
				#log('MESSAGE LENGTH IS %d' % message_length)
				if message_length == 0:
					#log('KEEP ALIVE')
					self.buffer = self.buffer[4:]
				elif len(self.buffer[4:]) >= message_length:
					message = self.buffer[4:message_length+4]
					#log('MESSAGE %d' % message)
					self.dispatch_message(message)
					self.buffer = self.buffer[message_length+4:]
					
	def dispatch_message(self, message):
		message_id = unpack('!B', message[0])[0]
		message_body = message[1:]
		#log('%s:%d MESSAGE %d' % (self.ip,self.port,message_id))
		if message_id < len(self.messages.message_function):
			self.messages.message_function[message_id](self, message_body)
		else:
			log('%s:%d UNKNOWN MESSAGE %d' % (self.ip,self.port,message_id))
		
	def update_pieces_have(self, pieces_have=None, piece_index=None):
		if pieces_have:
			#log('self.pieces_have is %d and pieces_have is %d' % (len(self.pieces_have), len(pieces_have)))
			for i in range(0, min(len(self.pieces_have), len(pieces_have)), 1):
				self.pieces_have[i] = pieces_have[i]
		elif piece_index and piece_index < len(self.pieces_have):
			self.pieces_have[piece_index] = True
		
		self.downloader.pieces_changed_callback(self)
	
	def block_received(self, piece, piece_index, piece_offset):
		if not self.active:
			#self.timeout_callback.cancel()
			self.active = True
			self.downloader.active_peers.append(self.key)
		
		block_offset = piece_index * self.downloader.torrent.piece_length + piece_offset
		self.blocks_received[block_offset] = clock() - self.blocks_requested[block_offset]
		self.speed = len(piece) / 1024 / float(self.blocks_received[block_offset]) if self.blocks_received[block_offset] else 0
		#avg_speed = self.downloader.download_speed/float(len(self.downloader.active_peers))
		#avg_speed = sum(self.downloader.peers[peer_key].speed for peer_key in self.downloader.active_peers) / len(self.downloader.active_peers)
		#log('speed %d Kb/s - %d Kb/s' % (self.speed, avg_speed))
		
		self.request_count = (self.request_count - 1) if self.request_count > 0 else 0
		#if self.speed >= avg_speed or len(self.downloader.active_peers) <= MIN_ACTIVE_PEERS:
		self.downloader.check_piece_callback(piece, piece_index, piece_offset, self)
		#elif not self.request_count:
		#	self.handle_close()
			
	def send_message(self, message_id):
		self.messages.send_message(peer=self, message_id=message_id)
	
	def request_block(self, piece_index, block_index, block_length=BLOCK_LENGTH):
		if not piece_index in self.pieces_interested:
			self.pieces_interested.append(piece_index)
			self.send_message(message_id=2)

		self.request_count += 1
		block_offset = piece_index*self.downloader.torrent.piece_length+block_index*BLOCK_LENGTH
		self.last_request = clock()
		self.blocks_requested[block_offset] = self.last_request
		self.messages.construct_request_payload(peer=self, piece_index=piece_index, piece_offset=block_index*BLOCK_LENGTH, piece_length=block_length)
		#log('%s:%d REQUEST BLOCK %d FROM PIECE %d' % (self.ip, self.port, block_index, piece_index))