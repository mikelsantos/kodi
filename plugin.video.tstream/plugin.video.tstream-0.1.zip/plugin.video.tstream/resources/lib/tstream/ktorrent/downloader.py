from asyncore import ExitNow
from math import trunc
from os import makedirs, path
from struct import pack, unpack
from time import time, sleep

from constants import BLOCK_LENGTH, DEFAULT_HOST, DEFAULT_PORT, DHT_REBOOT_TIME, MIN_ACTIVE_PEERS, MIN_DOWNLOAD_SPEED, MAX_ACTIVE_PEERS, MAX_PEER_REQUESTS, MAX_STARTED_PEERS, STREAM_BUFFER_PIECES
from logger import log
from peer import Peer
from tracker import Tracker

from scheduler import CallLater

class Downloader(object):
	def __init__(self, torrent, file, download_dir, file_offset=0):
		self.host = DEFAULT_HOST
		self.port = DEFAULT_PORT #TODO: (6881,6889)
		self.torrent = torrent
		self.requests = [[0] * self.torrent.blocks_per_piece for i in range(0,self.torrent.number_of_pieces,1)]
		self.file = file
		self.pieces_left = self.torrent.get_file_pieces(file)
		self.pieces_first = self.get_first_pieces()
		self.download_dir = download_dir
		self.complete = False
		self.updating_peers = False
		self.downloaded_bytes = 0
		self.downloaded_percent = 0.0
		self.download_speed = 0
		self.peers = {}
		self.started_peers = []
		self.active_peers = []
		self.start_time = time()
		#self.trackers = self.parse_trackers(self.torrent.announce_list)
		#self.torrent.dht.get_peers(info_hash=self.torrent.info_hash, callback=self.add_peers)
		self.dht_loop = None
		self.parse_dht()
	
	def stop(self):
		if self.dht_loop:
			self.dht_loop.cancel()
		peers = dict(self.peers)
		for key in peers:
			peer = peers[key]
			if peer.connected:
				peer.handle_close()
			self.del_peer((peer.ip, peer.port), False)
			
	def parse_dht(self):
		log('parse_dht')
		if not self.complete:
			timeout = DHT_REBOOT_TIME + self.download_speed/DHT_REBOOT_TIME # 10 o 5
			self.dht_loop = CallLater(timeout, self.parse_dht)
			
			if self.download_speed < MIN_DOWNLOAD_SPEED or len(self.active_peers) < MIN_ACTIVE_PEERS:
				self.torrent.dht.get_peers(info_hash=self.torrent.info_hash, callback=self.add_peers)
		
	def parse_trackers(self, announce_list):
		trackers = []
		for tracker_list in announce_list:
			for tracker_uri in tracker_list:
				trackers.append(Tracker(self, tracker_uri, self.get_params(), callback=self.add_peer))
		return trackers
			
	def get_first_pieces(self):
		pieces_first = []
		while len(pieces_first) < max(1024*1024/self.torrent.piece_length, STREAM_BUFFER_PIECES)*2:
			pieces_first.append(self.pieces_left.pop(0))
			pieces_first.append(self.pieces_left.pop())
		
		log(pieces_first)
		return pieces_first
			
	def get_params(self):
		return {
		'info_hash': self.torrent.info_hash,
		'event': 'started',
		'downloaded': self.torrent.downloaded,
		'uploaded' : self.torrent.uploaded,
		'peer_id': self.torrent.peer_id,
		'port': self.port,
		'left': (self.torrent.length-self.torrent.downloaded),
		'compact': '1',
		}

	def get_peer_key(self, peer):
		ip = peer[0]
		port = peer[1]
		return str(ip) + ':' +  str(port)
		
	def add_peers(self, peers):
		for peer in peers:
			self.add_peer(peer)
	
	def add_peer(self, peer):
		#log('adding peer %s:%d' % (peer[0], peer[1]))
		ip = peer[0]
		port = peer[1]
		peer_key = self.get_peer_key(peer)
		if ip != self.host and ip != '0.0.0.0' and port > 0 and not peer_key in self.peers:
			self.peers[peer_key] = Peer(self, ip, port)
			if len(self.started_peers) < MAX_STARTED_PEERS and len(self.active_peers) < MAX_ACTIVE_PEERS: 
				self.peers[peer_key].start()
				self.started_peers.append(peer_key)
			else:
				self.peers[peer_key] = Peer(self, ip, port)
	
	def del_peer(self, peer, update_peers=True):
		peer_key = self.get_peer_key(peer)
		peers = dict(self.peers)
		if peer_key in peers:
			if peers[peer_key].started:
				peers[peer_key].started = False
				if peer_key in self.started_peers:
					self.started_peers.remove(peer_key)
			if peers[peer_key].active:
				peers[peer_key].active = False
				if peer_key in self.active_peers:
					self.active_peers.remove(peer_key)
			if update_peers and (self.download_speed < MIN_DOWNLOAD_SPEED or len(self.active_peers) < MIN_ACTIVE_PEERS) and self.active_peers < MAX_ACTIVE_PEERS:
				self.update_peers()
		
	def update_peers(self):
		if not self.updating_peers:
			self.updating_peers = True
			peers = dict(self.peers)
			for peer_key in peers:
				if len(self.started_peers) >= MAX_STARTED_PEERS or len(self.active_peers) >= MAX_ACTIVE_PEERS:
					break
				if peers[peer_key].valid and not peers[peer_key].started:
					peers[peer_key].start()
					self.started_peers.append(peer_key)
			self.updating_peers = False
		
	def pieces_changed_callback(self, peer):
		if not self.complete:
			total_pieces = self.pieces_first + self.pieces_left
			if len(self.pieces_first) + len(self.pieces_left) > 0:
				i = 0
				while i < len(total_pieces):
					if peer.request_count >= MAX_PEER_REQUESTS:
						break
					piece_index = total_pieces[i]
					start_block = 0
					end_block = len(self.torrent.blocks_have[piece_index]) - 1
					for block_index in range(start_block, end_block + 1, 1):
						if peer.request_count >= MAX_PEER_REQUESTS:
							break
						#elif self.requests[piece_index][block_index] > MAX_PEER_REQUESTS: # MAX 8 REQUESTS PER BLOCK
						#	continue
						else:
							block_offset = piece_index*self.torrent.piece_length + block_index*BLOCK_LENGTH
							block_length = (self.torrent.length-block_offset) if piece_index == self.torrent.number_of_pieces-1 and block_index == end_block else BLOCK_LENGTH
							if not self.torrent.blocks_have[piece_index][block_index] and not block_offset in peer.blocks_requested:
								self.requests[piece_index][block_index] += 1
								peer.request_block(piece_index, block_index, block_length)
								#if piece_index + 1 < len(total_pieces) and peer.request_count > 5: # make half the MAX_PEER_REQUESTS to a different piece
								#	break
					i += 1
			else:
				finish_time = time() - self.start_time
				log('100%% FINISHED in %02d:%02d' % (finish_time/60, finish_time%60))
				self.complete = True

	def check_piece_callback(self, piece, piece_index, piece_offset, peer):		
		block_index = int(piece_offset/float(BLOCK_LENGTH))
		block_offset = piece_index * self.torrent.piece_length + piece_offset
		
		self.requests[piece_index][block_index] = (self.requests[piece_index][block_index] - 1) if self.requests[piece_index][block_index] > 0 else 0
		
		if not self.torrent.blocks_have[piece_index][block_index]:
			self.torrent.blocks_have[piece_index][block_index] = True
			self.downloaded_bytes += len(piece)
			self.downloaded_percent = int(float(self.downloaded_bytes)/float(self.file['length'])*100)
			self.download_speed = int(self.downloaded_bytes/1024/(time()-self.start_time))
			
			self.write_block(piece, piece_index, block_index)
						
			if self.torrent.has_piece(piece_index):
				full_piece = self.read_piece(piece_index)
				piece_hash = self.torrent.get_hash(full_piece)
				hash_from_info = self.torrent.piece_hashes[piece_index]				
				if piece_hash == hash_from_info:
					log('[%02d%%] PIECE %03d @ %04d K/s PEERS %d' % (self.downloaded_percent, piece_index, self.download_speed, len(self.active_peers)))
					if piece_index in self.pieces_first:
						self.pieces_first.remove(piece_index)
					elif piece_index in self.pieces_left:
						self.pieces_left.remove(piece_index)
					self.torrent.downloaded += 1
				else:
					log('PIECE %d HASHES DO NOT MATCH' % piece_index)
					self.torrent.set_piece(piece_index, False)
					self.downloaded_bytes -= len(full_piece)
		else:
			self.download_speed = int(self.downloaded_bytes/1024/(time()-self.start_time))
		self.pieces_changed_callback(peer)
	
	def get_file_path(self):
		return self.get_download_path(self.file)
		
	def get_download_path(self, file):
		download_path = path.join(self.download_dir, file['name'])
		if not path.exists(self.download_dir): # if path does not exist, create
			makedirs(self.download_dir)
		if not path.exists(download_path): # if file does not exist, create
			open(download_path, 'a').close()
		
		return download_path
	
	def get_files_in_range(self, begin_offset, end_offset):
		files = []
		for file in self.torrent.files:
			if end_offset >= file['begin_offset'] and begin_offset <= file['end_offset']:
				file['path'] = self.get_download_path(file)
				files.append(file)
		
		return files
		
	def get_files_from_block(self, piece_index, block_index, block_length):
		begin_offset = piece_index * self.torrent.piece_length + block_index*BLOCK_LENGTH
		end_offset = begin_offset + block_length
		return self.get_files_in_range(begin_offset, end_offset)
		
	def get_files_from_piece(self, piece_index):
		begin_offset = piece_index * self.torrent.piece_length
		end_offset = begin_offset + self.torrent.piece_length
		return self.get_files_in_range(begin_offset, end_offset)
		
	def write_block(self, piece, piece_index, block_index=0):
		offset = piece_index * self.torrent.piece_length + block_index*BLOCK_LENGTH
		files = self.get_files_from_block(piece_index, block_index, len(piece))
		for file in files:
			file_path = file['path']
			file_offset = (offset - file['begin_offset']) if offset > file['begin_offset'] else 0
			block_begin = (file['begin_offset'] - offset) if file['begin_offset'] > offset else 0
			block_end = (file['end_offset'] - offset) if file['end_offset'] < (offset + len(piece)) else len(piece)
			#log('WRITING PIECE %d LENGTH %d TORRENT OFFSET %d [%d:%d] FROM FILE OFFSET [%d:+%d] NAME %s' % (piece_index, self.torrent.piece_length, offset, block_begin, block_end, file_offset, (block_end-block_begin), file_path))
			try:
				with open(file_path, 'rb+') as torrent_file:
					torrent_file.seek(file_offset)
					torrent_file.write(piece[block_begin:block_end])
			except IOError: # FILE DOES NOT EXIST
				with open(file_path, 'wb+') as torrent_file:
					torrent_file.seek(file_offset)
					torrent_file.write(piece[block_begin:block_end])
			
	def read_piece(self, piece_index): # TODO: read from multiple files
		piece = ''
		piece_length = self.torrent.length-(self.torrent.number_of_pieces-1)*self.torrent.piece_length if piece_index == self.torrent.number_of_pieces-1 else self.torrent.piece_length
		offset = piece_index * self.torrent.piece_length
		files = self.get_files_from_piece(piece_index)
		for file in files:
			file_path = file['path']
			file_offset = (offset - file['begin_offset']) if offset > file['begin_offset'] else 0
			block_begin = (file['begin_offset'] - offset) if file['begin_offset'] > offset else 0
			block_end = (file['end_offset'] - offset) if file['end_offset'] < (offset + piece_length) else piece_length
			#log('READING PIECE %d LENGTH %d TORRENT OFFSET %d [%d:%d] FROM FILE OFFSET [%d:+%d] NAME %s' % (piece_index, self.torrent.piece_length, offset, block_begin, block_end, file_offset, (block_end-block_begin), file_path))
			try:
				with open(file_path, 'rb') as downloaded_file:
					downloaded_file.seek(file_offset)
					piece += downloaded_file.read(block_end-block_begin)
			except Exception, e:
				log('ERROR: read_piece %d from file %s' % (piece_index, file_path))
				log('%s' % str(e))
		
		return piece
