from hashlib import sha1
from urllib2 import Request, URLError, urlopen
from math import ceil, trunc
from os import makedirs, path
from random import randrange
from tempfile import gettempdir
from threading import Thread

from bencode import bencode, bdecode
from bitstring import BitArray
from constants import BLOCK_LENGTH, HTTP_HEADERS
from dht import DHT
from downloader import Downloader
from logger import log

import scheduler

class Torrent(object):
	def __init__(self):
		self.peer_id = '-'.join(['','TZ', '0000', str(randrange(10000000000,99999999999))])
		self.downloader = None
		self.loop_thread = None
		self.dht = None
		
	def start(self, torrent_path, download_dir=None):
		self.stop()
		self.torrent_path = torrent_path
		self.download_dir = download_dir if download_dir else gettempdir()
		self.data = self.parse_torrent(self.torrent_path)
		self.dht = DHT(peer_id=self.peer_id)
		self.info = self.data['info'] if 'info' in self.data else None
		self.info_hash = self.data['info_hash'] if 'info_hash' in self.data else None
		self.info_hash = self.get_hash(bencode(self.info)) if self.info else None
		if self.info: self.parse_info()
						
	def stop(self):
		scheduler.close_all()
		if self.dht:
			self.dht.stop()
			self.dht = None
		if self.downloader:
			self.downloader.stop()
			self.downloader = None
		if self.loop_thread:	
			self.loop_thread.join(1)
			self.loop_thread = None
						
	def parse_info(self):
		self.files = self.parse_files(self.info)
		self.length = self.get_total_length(self.files)
		self.pieces = self.info['pieces']
		self.piece_hashes = [self.pieces[i:i+20] for i in range(0, len(self.pieces), 20)]
		self.piece_length = self.info['piece length']
		log(1024*1024 / self.piece_length)
		self.number_of_pieces = int(ceil(self.length / float(self.piece_length)))
		self.blocks_per_piece = int(self.piece_length / float(BLOCK_LENGTH))
		self.announce = self.data['announce'] if 'announce' in self.data else None
		self.announce_list = self.data['announce-list'] if 'announce-list' in self.data else [[self.announce]] 
		#self.pieces_have = [0] * self.number_of_pieces
		self.blocks_have = self.init_blocks()
		self.downloaded = 0
		self.uploaded = 0
		self.left = 0
		
	def download(self, file_index, download_dir=None, threaded=False):
		file = self.files[file_index]
		download_dir = download_dir if download_dir else self.download_dir
		self.downloader = Downloader(self, file, download_dir)
		self.loop_thread = Thread(target=scheduler.loop) if threaded else None
		if self.loop_thread:
			self.loop_thread.setDaemon(True)
			self.loop_thread.start()
			
	def get_download_path(self, file, download_dir=None):
		self.download_dir = download_dir if download_dir else self.download_dir
		download_path = path.join(self.download_dir, file['name'])
		if not path.exists(self.download_dir): # if path does not exist, create
			makedirs(self.download_dir)
		if not path.exists(download_path): # if file does not exist, create
			open(download_path, 'a').close()
		
		return download_path
	
	def get_file_pieces(self, file):
		file_start_piece = file['index']
		file_end_piece = file_start_piece + file['pieces']
		pieces_left = [piece_index for piece_index in range(file_start_piece, file_end_piece, 1)]
		
		return pieces_left
		#return self.resume_download(file, pieces_left)
		
	def resume_download(self, file, pieces_left):
		download_path = self.get_download_path(file)
		log('download path is %s' % download_path)
		file_len = path.getsize(download_path)
		with open(download_path, 'rb') as downloaded_file:
			for piece_index in range(file['index'], file['index']+file['pieces'], 1):
				downloaded_file.seek(piece_index*self.piece_length)
				piece = downloaded_file.read(self.piece_length)
				if piece:
					piece_hash = self.get_hash(piece)
					if piece_hash == self.piece_hashes[piece_index] and piece_index in pieces_left:
						pieces_left.remove(piece_index)
						log('GOT PIECE INDEX %d' % piece_index)
					else:
						break
		
		return pieces_left
		
	def init_blocks(self):
		blocks_have = []
		number_of_blocks = int(ceil(self.length/float(BLOCK_LENGTH)))
		blocks_per_piece = int(ceil(self.piece_length/float(BLOCK_LENGTH)))
		bytes_last_piece = self.length-trunc(self.length/float(self.piece_length))*self.piece_length
		blocks_last_piece = int(ceil(bytes_last_piece/float(BLOCK_LENGTH)))
		for i in range(0,trunc(self.length/float(self.piece_length)),1):
			blocks_have.append(BitArray(blocks_per_piece)) 
		if self.length > len(blocks_have)*self.piece_length:
			blocks_have.append(BitArray(blocks_last_piece))		
				
		return blocks_have
				
	def parse_torrent(self, link):
		torrent_data = None
		if link.startswith('magnet://'):
			log('Magnet file: %s' % link)
			torrent_data = None
		elif link.startswith('http://') or link.startswith('https://'):
			log('Torrent uri: %s' % link)
			try:
				request = Request(link, headers=HTTP_HEADERS)
				response = urlopen(request)
				torrent_data = response.read()
				response.close()
			except URLError as e:
				log(e.reason)
		elif path.exists(link) and path.isfile(link):
			log('File path: %s' % link)
			try:
				with open(link,'rb') as file:
					torrent_data = file.read()
					file.close()
			except IOError as e:
				log(e.reason)
		else:
			log('Invaled torrent input')
			
		if torrent_data:
			return bdecode(torrent_data)
		else:
			return None
	
	def parse_files(self, info):
		torrent_files = list()
		total_length = 0
		piece_number = 0
		piece_index = 0
		begin_offset = 0
		if 'files' in info and 'name' in info:
			#log('Multiple files')
			dir = info['name']
			for file in info['files']:
				path = dir
				if 'path' in file and 'length' in file:
					path = path.join(file['path'])
					piece_number = int(ceil(file['length'] / float(info['piece length'])))
					end_offset = (begin_offset + file['length']) #% info['piece length']
					torrent_files.append({'name': path, 'length': file['length'], 'index':piece_index, 'begin_offset':begin_offset, 'end_offset':end_offset, 'pieces':piece_number})
					total_length += file['length']
					piece_index = int(trunc(total_length / float(info['piece length'])))
					begin_offset = total_length #% info['piece length']
		elif 'length' in info and 'name' in info:
			#log('Single file')
			piece_number = int(ceil(info['length'] / float(info['piece length'])))
			end_offset = (begin_offset + info['length']) #% info['piece length']
			torrent_files.append({'name': info['name'], 'length': info['length'], 'index':piece_index, 'begin_offset':begin_offset, 'end_offset':end_offset, 'pieces':piece_number})
			total_length = info['length']
			
		log(torrent_files)
		return torrent_files
	
	def has_piece(self, piece_index):
		return self.blocks_have[piece_index].all(True)
	
	def set_piece(self, piece_index, value=True):
		return self.blocks_have[piece_index].set(value)
	
	def get_piece_from_offset(self, file, file_offset=0):
		return trunc((file['begin_offset'] + file_offset)/float(self.piece_length)) % self.number_of_pieces
		
	def get_critical_piece_number(self):
		return min(int(1024*1024/self.piece_length), 2)
		
	def get_total_length(self, files):
		total_length = 0
		for file in files:
			total_length += file['length']
		return total_length
		
	def get_hash(self, data):
		sha = sha1(data)
		hash = sha.digest()
		return hash