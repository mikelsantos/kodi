from logger import log
from struct import pack, unpack
from constants import BLOCK_LENGTH

class Messages(object):
	def __init__(self, torrent):
		self.torrent = torrent
		self.message_function = [
			self.choke,
			self.unchoke,
			self.interested,
			self.not_interested,
			self.have,
			self.bitfield,
			self.request,
			self.piece,
			self.cancel, 
			self.port,
		]

	def handshake(self):
		'''handshake: <len=0019><'BitTorrent protocol'><00000000><ID>#<pstrlen><pstr><reserved>
		'''
		pstr = 'BitTorrent protocol'
		pstrlen = chr(len(pstr))
		reserved = '\x00\x00\x00\x00\x00\x00\x00\x00'
		info_hash = self.torrent.info_hash
		peer_id = self.torrent.peer_id
		return pstrlen+pstr+reserved+info_hash+peer_id

	def choke(self, peer, message_bytes):
		'''choke: <len=0001><id=0>
		''' 
		peer.state['peer_choking'] = True 
		
	def unchoke(self, peer, message_bytes):
		''' unchoke: <len=0001><id=1>
		''' 
		peer.state['peer_choking'] = False
	
	def interested(self, peer, message_bytes):
		''' interested: <len=0001><id=2>
		'''
		peer.state['peer_interested'] = True
		
	def not_interested(self, peer, message_bytes):
		''' not interested: <len=0001><id=3>
		'''
		peer.state['peer_interested'] = False
	
	def have(self, peer, message_bytes):
		''' Have message is the index of a piece the peer has. Updates
			peer.pieces_have.
			have: <len=0005><id=4><piece index>
		'''
		piece_index = unpack('!L',message_bytes)[0]
		peer.update_pieces_have(piece_index=piece_index)
		
	def bitfield(self, peer, message_bytes):
		''' formats each byte into binary and updates peer.pieces_have list
			appropriately.
		'''
		bitstring = ''.join(format(x, 'b') for x in bytearray(message_bytes))
		pieces_have = [bool(int(c)) for c in bitstring]
		peer.update_pieces_have(pieces_have=pieces_have)
	
	def request(self, peer, message_bytes):
		''' <len=0013><id=6><index><offset><length>
			Calls torrent.get_piece() and sends relevent piece to peer.
		'''
		index = message_bytes[:4]
		offset = message_bytes[4:8]
		length = message_bytes[8:]
		#payload_bytes = self.torrent.downloader.construct_request_payload(index, offset, length, peer)
	
	def piece(self, peer, message_bytes):
		''' Piece message is constructed:
			<len=9 + X><id=8><index><offset><piece bytes>
		'''
		index = message_bytes[:4]
		offset = message_bytes[4:8]
		piece = message_bytes[8:]
		
		piece_index = unpack('!L', index)[0]
		piece_offset = unpack('!L', offset)[0]
		
		peer.block_received(piece, piece_index, piece_offset)
	
	def cancel(self, peer, message_bytes):
		'''cancel: <len=0013><id=8><index><begin><length>
		'''
		pass
	
	def port(self, peer, message_bytes):
		''' port: <len=0003><id=9><listen-port>
		'''
		pass
	
	def construct_request_payload(self, peer, piece_index, piece_offset=0, piece_length=BLOCK_LENGTH):
		''' Constructs the payload of a request message for piece_index.
			Calls peer.send_message to finish construction and send.
		'''
		piece_index_bytes = pack('!L', piece_index)
		piece_begin = pack('!L', piece_offset)
		piece_length = pack('!L', piece_length)
		payload = ''.join([piece_index_bytes, piece_begin, piece_length])
		self.send_message(peer, 6, payload)
	
	def send_message(self, peer, message_id, payload_bytes=''):
		''' Send message and update self.state if necessary
		
		messages in the protocol take the form of 
		<length prefix><message ID><payload>. The length prefix is a four byte 
		big-endian value. The message ID is a single decimal byte. 
		The payload is message dependent.
		'''
		#log('SENDING MESSAGE: %d' % message_id)
		length_bytes = pack('!L', 1 + len(payload_bytes))
		message_id_bytes = pack('!B', message_id)
		elements = [length_bytes, message_id_bytes, payload_bytes]
		message_bytes = ''.join(elements)
		peer.send(message_bytes)
		if message_id in [0,1,2,3]:
			self.update_state(peer, message_id)
	
	def update_state(self, peer, message_id):
		if message_id == 0:
			peer.state['am_choking'] = True
		elif message_id == 1:
			peer.state['am_choking'] = False
		elif message_id == 2:
			peer.state['am_interested'] = True
		elif message_id == 3:
			peer.state['am_interested'] = False
	