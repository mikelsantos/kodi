import asyncore
import socket
from hashlib import sha1
from random import randrange
from struct import pack, unpack
from time import clock, time, sleep

from bencode import bencode, bdecode
from constants import DHT_BOOTSTRAP_NODES, DHT_DEFAULT_HOST, DHT_DEFAULT_PORT, DHT_MAX_NODES, DHT_REBOOT_TIME, DHT_VERSION, RECV_BUFFER_SIZE
from logger import log
from scheduler import CallLater

def numToDottedQuad(n):
	d = 256 * 256 * 256
	q = []
	while d > 0:
		m, n = divmod(n, d)
		q.append(str(m))
		d /= 256
	return '.'.join(q)

def decode_nodes(nodes):
	response = []
	nrnodes = len(nodes) / 26
	nodes = unpack('!' + '20sIH' * nrnodes, nodes)
	for i in xrange(nrnodes):
		node_id, ip, port = nodes[i * 3], numToDottedQuad(nodes[i * 3 + 1]), nodes[i * 3 + 2]
		response.append({'id':node_id, 'ip':ip, 'port':port})
		
	return response

class Node(object):
	def __init__(self, c):
		self.c = c
		self.treq = 0
		self.trep = 0
		self.t = set()

class KRPCServer(asyncore.dispatcher):
	def __init__(self, host, port, node_id):
		asyncore.dispatcher.__init__(self)
		self.host = host
		self.port = port
		self.node_id = node_id
		self.transaction_id = 0
		self.transactions = {}
		self.results = {}
		self.nodes = {}
		self.buffer = []
		
	def start(self):
		self.create_socket(socket.AF_INET, socket.SOCK_DGRAM)
		self.bind((self.host, self.port))
		
	def handle_read(self):
		try:
			rec, c = self.recvfrom(RECV_BUFFER_SIZE)
			#log('KRPC receive')
			try:
				rec = bdecode(rec)
			except:
				return
			if 'y' in rec:
				if rec['y'] == 'r':
					#log('REPLY')
					t = rec['t']
					if t in self.transactions:
						node = self.transactions[t]['node']
						node.trep = clock()
						if t in node.t:
							node.t.remove(t)
						if self.transactions[t]['callback'] is not None:
							args = {'rec':rec, 'node':node}
							if 'args' in self.transactions[t] and self.transactions[t]['args']:
								args['args'] = self.transactions[t]['args']
							self.transactions[t]['callback'](args) # invoke the callback
						else:
							self.results[t] = rec # sync path
						del self.transactions[t] 
				elif rec['y'] == 'q':
					# It's a request, send it to the handler.
					#log('REQUEST')
					#self.close()
					pass
					#self.handler(rec,c)
				elif rec['y'] == 'e':
					log('DHT handle_read response error')
					if 't' in rec:
						t = rec['t']
						if t in self.transactions:
							del self.transactions[t]
							self.results[t] = rec
					else:
						log('Node %r reported error %r, but did not specify a t' % (c, rec))
					#self.close()
			else:
				log('Unknown KRPC message %r from %r' % (rec, c))
		except socket.error, e:
			log('DHT handle_read socket error %s' % str(e))
			#self.handle_close()
		except Exception, e:
			log('DHT handle_read error %s' % str(e))
			#self.handle_close()
	
	def handle_write(self):
		if len(self.buffer) > 0:
			try:
				buffer = self.buffer.pop(0)
				self.sendto(buffer[0], buffer[1])
			except:
				pass
	
	def handle_close(self):
		self.close()
	
	def ping(self, node_id, node, callback=None, args=None):
		q = { "y":"q", "q":"ping", "a":{"id":node_id}}
		return self.send_krpc(q, node, callback, args)
	
	def find_node(self, node_id ,node, target, callback=None, args=None):
		q = { "y":"q", "q":"find_node", "a":{"id":node_id,"target":target}}
		return self.send_krpc(q, node, callback, args)
	
	def get_peers(self, node_id, node, info_hash, callback=None, args=None):
		q = { "y":"q", "q":"get_peers", "a":{"id":node_id,"info_hash":info_hash}}
		return self.send_krpc(q, node, callback, args)
	
	def announce_peer(self, node_id, node, info_hash, port, token, callback=None, args=None):
		# We ignore "name" and "seed" for now as they are not part of BEP0005
		q = {'a': {
			#'name': '',
			'info_hash': info_hash,
			'id': node_id,
			'token': token,
			'port': port},
			'q': 'announce_peer', 'y': 'q'}
		return self.send_krpc(q, node, callback, args)
	
	def send_krpc(self, req , node, callback=None, args=None):
		#log('KRPC request to %s:%d' % (node.c[0], node.c[1]))
		t = -1
		if 't' not in req: 
			self.transaction_id += 1
			req['t'] = pack('i', self.transaction_id)
		else:
			t = req['t']
		req['v'] = DHT_VERSION
		data = bencode(req)
	
		try:
			self.transactions[req['t']] = {'callback':callback, 'node':node, 'args':args}
			node.treq = clock()
			node.t.add(t)
			self.buffer.append([data, node.c])
			#self.sendto(data, node.c)
		except Exception, e:
			log('DHT send_krpc error %s' % str(e))
			#self.close()
			#self.start()
		
		return t
	
class DHT(object):
	def __init__(self, host=DHT_DEFAULT_HOST, port=DHT_DEFAULT_PORT, peer_id=None):
		self.host = host
		self.port = port
		self.node_id = peer_id if peer_id else sha1('-'.join(['','TZ', '0000', str(randrange(10000000000,99999999999))])).digest()
		self.nodes = {}
		self.start()

	def start(self):
		self.server = KRPCServer(self.host, self.port, self.node_id)
		self.server.start()
			
	def stop(self):
		if self.server:
			self.server.close()
			self.server = None
		
	def restart(self):
		self.stop()
		self.start()
		
	def get_peers(self, info_hash, callback):
		log('reboot get_peers')
		self.nodes.clear()
		for node in DHT_BOOTSTRAP_NODES:
			self.server.get_peers(self.node_id, Node(node), info_hash, self._get_peers, {'callback':callback, 'info_hash':info_hash})
		
	def _get_peers(self, args, max_nodes=DHT_MAX_NODES):
		if 'values' in args['rec']['r']:
			peers = []
			for peer in args['rec']['r']['values']:
				try:
					ip_length = 6
					ip = '.'.join(str(ord(i)) for i in peer[:ip_length-2])
					port = ord(peer[ip_length-2])*256 + ord(peer[ip_length-1])
					peers.append((ip, port))
				except:
					pass
			if 'args' in args and 'callback' in args['args']:
				args['args']['callback'](peers)
		elif 'nodes' in args['rec']['r']:
			nodes = decode_nodes(args['rec']['r']['nodes'])
			for node in nodes:
				if len(self.nodes) >= max_nodes:
					#self.restart()
					break
				elif not node['id'] in self.nodes:
					self.nodes[node['id']] = Node((node['ip'], node['port']))
					self.server.get_peers(self.node_id, self.nodes[node['id']], args['args']['info_hash'], self._get_peers, args['args'])
		else:
			#log('Unknown response')
			pass