import os
import sqlite3

import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
DATABASE_PATH = os.path.join(xbmc.translatePath('special://database'), ADDON_ID + '.db')
#xbmc.log('DATABASE PATH IS %s' % (DATABASE_PATH))

class database(object):
    def __init__(self):
        connection = sqlite3.connect(DATABASE_PATH)
        if connection:
            cursor = connection.cursor()
            cursor.execute('CREATE TABLE IF NOT EXISTS inputs (provider TEXT, input TEXT, uri TEXT, tstamp DATETIME DEFAULT CURRENT_TIMESTAMP)')
            connection.commit()
            cursor.close()
            connection.close()
            
    def get_input(self, provider):
        rows = None
        connection = sqlite3.connect(DATABASE_PATH)
        if connection:
            cursor = connection.cursor()
            cursor.execute("SELECT input,uri FROM inputs WHERE provider='%s' ORDER BY tstamp DESC" % provider)
            rows = cursor.fetchall()           
            cursor.close()
            connection.close()
        return rows
        
    def set_input(self, provider, input, uri):
        connection = sqlite3.connect(DATABASE_PATH)
        if connection:
            cursor = connection.cursor()
            cursor.execute("INSERT INTO inputs(provider, input, uri) VALUES('%s','%s','%s')" % (provider, input, uri))
            connection.commit()
            cursor.close()
            connection.close()
