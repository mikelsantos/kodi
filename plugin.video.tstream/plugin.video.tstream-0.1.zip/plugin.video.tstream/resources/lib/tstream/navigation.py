import os
import pickle
import sys
import torrent
import urllib
import urllib2
import urlparse
import xbmc
import xbmcvfs
import xbmcgui
import xbmcaddon
import xbmcplugin


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
HANDLE = int(sys.argv[1])

LAST_COMMAND = None # last command passed
LAST_PARAMS = None # last parameters passed
MODULE_NAME = 'main' # default module name to call

class closing(object):
    def __init__(self, thing):
        self.thing = thing
    def __enter__(self):
        return self.thing
    def __exit__(self, *exc_info):
        self.thing.close()

class NoRedirectHandler(urllib2.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        import urllib
        infourl = urllib.addinfourl(fp, headers, headers["Location"])
        infourl.status = code
        infourl.code = code
        return infourl
    http_error_300 = http_error_302
    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302

def parseParameters(inputString=sys.argv[2]):
    global LAST_COMMAND
    LAST_COMMAND = inputString

    parameters = {}
    p1 = inputString.find('?')
    if p1 >= 0:
        splitParameters = inputString[p1 + 1:].split('&')
        for nameValuePair in splitParameters:
            if (len(nameValuePair) > 0):
                pair = nameValuePair.split('=')
                key = pair[0]
                if len(pair) > 1:
                    value = urllib.unquote(urllib.unquote_plus(pair[1])).decode('utf-8')
                else:
                    value = ''
                parameters[key] = value      
    
    global LAST_PARAMS
    LAST_PARAMS = parameters
        
    return parameters
    
def getJsonFromUrl(url):
    import json
    with closing(urllib2.urlopen(url)) as response:
        if response.code >= 300 and response.code <= 307:
            item = xbmcgui.ListItem(path=response.geturl(), thumbnailImage=xbmc.getInfoLabel("ListItem.Art(thumb)"))
            xbmcplugin.setResolvedUrl(HANDLE, True, item)
            return
        payload = response.read()        
        if payload:
            return json.loads(payload)

def getContent(items):
    content = {}    
    content['content_type'] = ''
    content['items'] = items
    return content
    
def getItem(label='', label2='', icon='', thumbnail='', isPlayable=False, path=''):
    item = {}
    item['label'] = label
    item['label2'] = label2
    item['icon'] = icon
    item['thumbnail'] = thumbnail
    item['is_playable'] =  isPlayable
    item['path'] = path    
    return item
    
def getLastPluginPath(oldParams, newParams):
    path = None
    for key,value in oldParams.iteritems():
        try:
            if not path:
                if key in newParams:
                    path = '?%s=%s' % (key, newParams[key])
                else:
                    path = '?%s=%s' % (key, value)
            else:
                if key in newParams:
                    path = '%s&%s=%s' % (path, key, newParams[key])
                else:
                    path = '%s&%s=%s' % (path, key, value)
        except:
            pass
    
    return 'plugin://%s/%s' % (ADDON_ID, path)
  
def test(args=None):
    xbmc.log('TEST FUNCTION WAS CALLED!!!')
  
def setMenu(data=None):        
    if not data:
        return    
    
    # save window content for future use (e.g. window refresh)
    window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    window.setProperty("listitems", pickle.dumps(data["items"]))
            
    xbmcplugin.setContent(HANDLE, 'movies')        
    
    if data["content_type"]:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)
        xbmcplugin.setContent(HANDLE, data["content_type"])
    
    listitems = range(len(data["items"]))        
    for i, item in enumerate(data["items"]):
        listItem = xbmcgui.ListItem(label=item["label"], label2=item["label2"], iconImage=item["icon"], thumbnailImage=item["thumbnail"])
        if item.get("infoLabels"):            
            listItem.setInfo("video", item["infoLabels"])
        if item.get("stream_info"):
            for type_, values in item["stream_info"].items():
                listItem.addStreamInfo(type_, values)
        if item.get("art"):
            listItem.setArt(item["art"])        
        if item.get("context_menu"):
            listItem.addContextMenuItems(item["context_menu"], True)
        elif LAST_PARAMS and (item["path"].find("callback=")<0 or item["path"].find("play=True")>=0):
            contextMenu = []
            #contextMenu.append(('Info', 'RunScript(%s)' % ADDON_ID))
            #contextMenu.append(('Info', 'Container.Update(%s&index=%d)' % (getLastPluginPath(LAST_PARAMS, {'callback':'infoLabels', 'args':item['args']}), i)))
            contextMenu.append(('Info', 'RunPlugin(%s&index=%d)' % (getLastPluginPath(LAST_PARAMS, {'callback':'infoLabels', 'args':item['args']}),i)))
            listItem.addContextMenuItems(contextMenu, True)
        listItem.setProperty("isPlayable", item["is_playable"] and "true" or "false")
        if item.get("properties"):
            for k, v in item["properties"].items():
                listItem.setProperty(k, v)
        listitems[i] = (item["path"], listItem, not item["is_playable"])        
    
    xbmcplugin.addDirectoryItems(HANDLE, listitems, totalItems=len(listitems))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)                

def setSysPath(path):
    unsetSysPath(path)
    sys.path.insert(0, path)        
        
def unsetSysPath(path):
    removePaths = []    
    for sysPath in sys.path:
        sysPath = os.path.abspath(sysPath)
        if path == sysPath:
            removePaths.append(path)
            
    for removePath in removePaths:
        sys.path.remove(removePath)
    
def callRemote(addonName, moduleName, functionName, parameter=None):
    retValue = None
    
    if addonName:
        setSysPath(ADDON.getAddonInfo('path').replace(ADDON_ID, addonName))
    
    try:                            
        module = __import__(moduleName)
        xbmc.log('IMPORTED MODULE %s' % module)
        if hasattr(module, functionName):            
            if parameter:
                retValue = getattr(module, functionName, None)(parameter)
            else:
                retValue = getattr(module, functionName, None)()
        del sys.modules[moduleName]
    except:
        pass
    
    if addonName:    
        unsetSysPath(ADDON.getAddonInfo('path').replace(ADDON_ID, addonName))
        
    return retValue
    
def searchPlugins():           
    xbmc.log('SEARCH PLUGINS')
    items = []
    path = ADDON.getAddonInfo('path')
    dirs, files = xbmcvfs.listdir('%s/..' % path)    
    for dir in dirs:
        if dir.startswith('script.tstream.'):
            provider = xbmcaddon.Addon(dir).getAddonInfo('name') #dir[len('script.tstream.'):] #callRemote(dir, 'main', 'name')
            xbmc.log('FOUND PROVIDER NAME %s' % provider)
            callPath = 'plugin://%s?provider=%s' % (ADDON_ID, dir)
            iconPath = os.path.join(ADDON.getAddonInfo('path'),'..',dir,'icon.png') 
            items.append(getItem(provider, iconPath, iconPath, '', False, callPath))                    
    
    return items    

def getCurrentViewId():
    viewId = None
    try:
        window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        viewId = window.getFocusId()
    except:
        pass
        
    return viewId
    
def run():
    xbmc.log('navigation.py run() argv=%s' % str(sys.argv))
    parameters = parseParameters()                        
    items = []
    
    if 'index' in parameters: # CUSTOM CONTEXT MENU ACTION SELECTED
        try:
            xbmc.log('navigation.py run() index found parameters=%s' % str(parameters))
            oldViewId = getCurrentViewId()
            provider = parameters['provider']
            callback = parameters['callback']
            args = parameters['args']
            index = int(parameters['index'])
            window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
            list = window.getFocus()
            #xbmc.log('CURRENT LIST IS %s' % str(list))
            #xbmc.log('CURRENT ITEM IS %s' % str(list.getSelectedPosition()))
            xbmcgui.Dialog().ok('Info', str(callRemote(provider, MODULE_NAME, callback, args)['plot']))
            #items = pickle.loads(window.getProperty('listitems'))           
            #items[index][callback] = callRemote(provider, MODULE_NAME, callback, args)                        
            #if items and len(items)>0: setMenu(getContent(items))
            #xbmc.executebuiltin('Container.SetViewMode(%d)' % oldViewId)
            #xbmc.executebuiltin('Control.Move(%d, %d)' % (list.getId(), index))
            #xbmc.executebuiltin('Container.Refresh()')
            #window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
            #cItem[callback] = callRemote(provider, MODULE_NAME, callback, args)
        except:
            pass
    else: # NORMAL FLOW: NO CUSTOM CONTEXT MENU ACTION SELECTED
        if not 'provider' in parameters:
            items = searchPlugins()
        else:
            provider = parameters['provider']
            
            args = None
            if 'args' in parameters:
                args = parameters['args']
            
            callback = None
            if 'callback' in parameters:
                callback = parameters['callback']
            elif not args:
                callback = 'init'            
                        
            play = None
            if 'play' in parameters:
                play = parameters['play']                    
            
            #xbmc.log('CALLING PROVIDER %s WITH CALLBACK %s AND ARGS %s AND PLAY %s' % (provider, callback, args, play))
            xbmc.log('FULL STRING IS %s' % (sys.argv[2].decode('utf-8', 'ignore').encode('utf-8', 'ignore')))
            
            if callback and callback.startswith('_input_'):
                callback = callback[len('_input_'):]
                keyboard = xbmc.Keyboard('')
                keyboard.doModal()
                if (keyboard.isConfirmed()):
                    args = args % urllib.quote_plus(keyboard.getText())
                    
            if not play or play == 'False':
                xbmc.log('CALLING: %s WITH ARGS: %s' % (callback, args))
                items = callRemote(provider, MODULE_NAME, callback, args)
                if items:
                    for item in items:                                    
                        xbmc.log('CALLBACK: %s ARGS: %s' % (callback, args))                    
                        if 'is_playable' in item and not item['is_playable'] and 'callback' in item and not item['callback']: item['callback'] = callback
                        if 'is_playable' in item and item['is_playable'] and not 'args' in item and item['path']: item['args'] = urllib.quote(item['path'])
                        if 'path' in item: item['path'] = 'plugin://%s?provider=%s' % (ADDON_ID, provider)
                        if 'callback' in item: item['path'] = '%s&callback=%s' % (item['path'], item['callback'])
                        if 'args' in item and item['args']: item['path'] = '%s&args=%s' % (item['path'], urllib.quote_plus(item['args']))
                        if 'is_playable' in item: item['path'] = '%s&play=%s' % (item['path'], item['is_playable'])
            else:
                if callback: args = callRemote(provider, MODULE_NAME, callback, args)
                link = urllib.unquote(args).encode('utf-8', 'ignore')
                xbmc.log('PATH IS: %s' % link)
                link = torrent.play(link)
                listItem = xbmcgui.ListItem(path=link)
                xbmcplugin.setResolvedUrl(HANDLE, True, listItem)        
        
        if items and len(items)>0:
            setMenu(getContent(items))