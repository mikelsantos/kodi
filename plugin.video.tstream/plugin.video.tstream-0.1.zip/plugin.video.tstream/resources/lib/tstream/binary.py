import os
import platform
import shutil
import signal
import subprocess
import stat
import sys
import xbmc

SW_HIDE = 0
STARTF_USESHOWWINDOW = 1

def runBinary(binary, args):
    system = getOperatingSystem()
    arch = getHostArchitecture()
    bin_dir =  '%s-%s' % (system, arch)
    xbmc.log('BINARY DIRECTORY %s' % bin_dir)
    if system == 'windows':
        src_dir = os.path.dirname(args)
        binary = os.path.join(src_dir, '..', 'bin', bin_dir, 'jx.exe')
        xbmc.log('Binary path is %s' % binary)
        command = [binary, args]
        si = subprocess.STARTUPINFO()
        si.dwFlags = STARTF_USESHOWWINDOW
        si.wShowWindow = SW_HIDE
        kwargs = {'startupinfo':si}
        process = subprocess.Popen(command, **kwargs)
    else:
        try:
            src_dir = os.path.dirname(args)
            binary = os.path.join(src_dir, '..', 'bin', bin_dir, 'jx')
            xbmc.log('HOME PATH IS %s' % xbmc.translatePath('special://home'))
            dst_dir = os.path.join("/data", "data", "org.xbmc.kodi", "files")
            dst_bin = os.path.join(dst_dir, "tstream")
            if os.path.exists(dst_bin):
                os.remove(dst_bin)
            xbmc.log('Copying file to %s' % dst_bin)
            shutil.copy(binary, dst_bin)
            xbmc.log('Setting permissions to %s' % dst_bin)
            st = os.stat(dst_bin)
            os.chmod(dst_bin, st.st_mode | stat.S_IEXEC)
            xbmc.log('Permissions set to %s' % dst_bin)
            #args = args.replace("/storage/emulated/0", "/storage/emulated/legacy")
            xbmc.log('Executing %s %s' % (dst_bin, args))
            command = [dst_bin, args]
            process = subprocess.Popen(command)
        except:
            xbmc.log('Error running torrent engine')                
    return process
    
def getOperatingSystem():
    system = ''
    if sys.platform == 'win32':
        system = 'windows'
    elif xbmc.getCondVisibility('system.platform.linux'):
        system = 'linux'
    elif xbmc.getCondVisibility('system.platform.android'):
        system = 'android'
    return system
    
def getHostArchitecture():
    out = ''
    if platform.machine().lower()[:3] == 'arm':
        out += 'arm'
    if sys.maxsize > 2 ** 32:
        if out == 'arm':
            out += '64'
        else:
            out = 'x64'
    else:
        if out == 'arm':
            out += '32'
        else:
            out = 'x86'
    return out
    
def killProcess(process):    
    if process: 
        xbmc.log('Killing process %', process.pid)
        process.kill()