import os
import platform
import shutil
import signal
import subprocess
import stat
import sys
import xbmc

SW_HIDE = 0
STARTF_USESHOWWINDOW = 1

def runBinary(binary, args):
    process = None
    system = getOperatingSystem()
    arch = getHostArchitecture()
    bin_dir =  '%s-%s' % (system, arch)
    xbmc.log('Binary is %s' % bin_dir)
    src_dir = os.path.dirname(args)
    src_dir = os.path.join(src_dir, '..', 'bin', bin_dir)
    src_files = os.listdir(src_dir)
    src_bin = src_files[0] if len(src_files) > 0 else None
    src_bin = os.path.join(src_dir, src_bin)
    xbmc.log('Source binary is %s' % src_bin)
    if src_bin:
        if system == 'windows':
            command = [src_bin, args]
            si = subprocess.STARTUPINFO()
            si.dwFlags = STARTF_USESHOWWINDOW
            si.wShowWindow = SW_HIDE
            kwargs = {'startupinfo':si}
            process = subprocess.Popen(command, **kwargs)
        else:
            try:
                dst_dir = xbmc.translatePath('special://xbmc')
                dst_bin = os.path.join(dst_dir, 'tstream')
                xbmc.log('Destination binary is %s' % dst_bin)
                if os.path.exists(dst_bin):
                    os.remove(dst_bin)
                    shutil.copy(src_bin, dst_bin)
                    xbmc.log('Setting permissions to %s' % dst_bin)
                    st = os.stat(dst_bin)
                    os.chmod(dst_bin, st.st_mode | stat.S_IEXEC)
                    xbmc.log('Permissions set to %s' % dst_bin)
                    #args = args.replace("/storage/emulated/0", "/storage/emulated/legacy")
                    xbmc.log('Executing %s %s' % (dst_bin, args))
                    command = [dst_bin, args]
                    process = subprocess.Popen(command)
            except:
                xbmc.log('Error running torrent engine')                
    return process
    
def getOperatingSystem():
    system = ''
    if sys.platform == 'win32':
        system = 'windows'
    elif xbmc.getCondVisibility('system.platform.android'):
        system = 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        system = 'linux'
    return system
    
def getHostArchitecture():
    out = None
    machine = platform.machine().lower()
    xbmc.log('Machine is: %s' % machine)
    if machine == 'arm':
        out = 'arm'
    elif machine in ['aarch64', 'aarch64_be', 'armv8b', 'armv8l']:
        out = 'arm64'
    elif machine in ['i386', 'i686']:
        out = 'x86'
    elif machine in ['amd64', 'x86_64']:
        out = 'x64'
    
    return out
    
def killProcess(process):    
    if process: 
        xbmc.log('Killing process %', process.pid)
        process.kill()