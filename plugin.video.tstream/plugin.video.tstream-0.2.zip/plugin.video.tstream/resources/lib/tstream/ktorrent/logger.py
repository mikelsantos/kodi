try:
	import xbmc
	XBMC = True
except:
	XBMC = False

def log(message):
	if XBMC:
		xbmc.log(str(message))
	else:
		print(message)