from threading import Timer

class CallLater(object):
	def __init__(self, seconds, target, *args, **kwargs):
		self.seconds = seconds
		self.target = target
		self.args = args
		self.kwargs = kwargs
		self._start()

	def _start(self):
		self.timer = Timer(self.seconds, self.target, self.args, self.kwargs)
		self.timer.start()
	
	def cancel(self):
		self.timer.cancel()
		
	def delay(self, seconds):
		self.cancel()
		self.seconds = seconds
		self._start()
		