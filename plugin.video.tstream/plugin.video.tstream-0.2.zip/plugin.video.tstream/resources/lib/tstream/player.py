import xbmc

class XBMCPlayer(xbmc.Player):
    def __init__( self, *args, **kwargs ):
        self.is_active = True
    
    def onPlayBackPaused( self ):
        xbmc.log("#Player paused#")
        
    def onPlayBackResumed( self ):
        xbmc.log("#Player resumed #")
        
    def onPlayBackStarted( self ):
        xbmc.log("#Player started#")
        
    def onPlayBackStopped( self ):
        self.is_active = False
        xbmc.log("#Player stopped#")        

        